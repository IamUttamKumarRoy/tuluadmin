<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        /* Schema::create('rit_features', function (Blueprint $table) {
            $table->id();
            $table->timestamps();
        }); */
		Schema::create('rit_features', function (Blueprint $table) {
            $table->id();
            $table->unsignedInteger('rit_id')->unique();
            $table->string('name', 200);
            $table->string('rit_freq', 100)->nullable();
            $table->unsignedInteger('data_frequency_id')->nullable();
            $table->unsignedInteger('rit_version')->default(1);
            $table->unsignedInteger('no_of_col')->nullable();
            $table->unsignedInteger('no_of_row')->nullable();
            $table->unsignedInteger('cut_off_days')->nullable();
            $table->string('dept', 100)->nullable();
            $table->unsignedInteger('department_id')->nullable();
            $table->string('status', 100)->nullable();
            $table->tinyInteger('status_id')->nullable();
            $table->tinyInteger('validate')->default(0);
            $table->timestamps();

            // Indexing for performance
            $table->index('rit_id');
            $table->index('rit_name');        
            $table->index('cut_off_days');    
            $table->index('rit_version');  

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('rit_features');
    }
};
