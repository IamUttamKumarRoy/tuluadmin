<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {         
		Schema::create('bank_fi_classes', function (Blueprint $table) {
            $table->id(); // Equivalent to INT PRIMARY KEY AUTO_INCREMENT
            $table->unsignedInteger('fi_class_id')->unique(); // fi_class_id 
            $table->string('fi_inst_type', 255)->nullable(); // fi_inst_type VARCHAR(255) NOT NULL
            $table->string('fi_category', 255)->nullable(); // fi_category VARCHAR(255) NOT NULL
            $table->string('fi_cluster', 255)->nullable(); // fi_cluster VARCHAR(255) NOT NULL
            $table->timestamps(); // Optional: Adds created_at and updated_at columns

            // Indexing for performance
            $table->index('fi_class_id');
            $table->index('fi_inst_type');
            $table->index('fi_category');
            $table->index('fi_cluster');
            
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('bank_fi_classes');
    }
}; 