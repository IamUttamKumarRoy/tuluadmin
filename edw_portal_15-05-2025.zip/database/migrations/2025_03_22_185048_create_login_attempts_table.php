<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    { 
		Schema::create('login_attempts', function (Blueprint $table) {
            $table->id();
            $table->string('user_id', 50);
            $table->string('password', 255)->nullable();
            $table->string('ip_address', 45)->nullable();
            $table->string('user_agent', 255)->nullable();
            $table->timestamp('attempt_time')->useCurrent();
            $table->boolean('success')->default(false);
            $table->timestamps();

            // Indexing for performance
            $table->index('user_id');
            $table->index('password');    
            $table->index('ip_address'); 
            $table->index('user_agent'); 
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('login_attempts');
    }
};
