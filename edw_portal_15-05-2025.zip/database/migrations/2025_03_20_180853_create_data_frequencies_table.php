<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
         
		Schema::create('data_frequencies', function (Blueprint $table) {
            $table->id(); // Equivalent to INT PRIMARY KEY AUTO_INCREMENT
            $table->string('short_name', 250)->nullable();  
            $table->string('full_name', 250)->unique();  
            $table->text('description')->nullable(); // NULLABLE
            $table->unsignedInteger('sorting_order')->nullable();
            $table->integer('status_id')->nullable(); // NULLABLE
            $table->timestamps(); // Adds created_at and updated_at columns

            // Indexing for performance
            $table->index('short_name');
            $table->index('full_name'); 
            $table->index('status_id');             
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('data_frequencies');
    }
};
