@if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
<form method="POST" action="{{ route('lab.captcha_validate') }}">
    @csrf

    <div>
        <label for="captcha">Enter Captcha:</label>
        <div>
            <img src="{{ url('/captcha') }}" alt="Captcha Image">
            <input id="captcha" type="text" name="captcha" value="{{ $captcha_val }}" required>
        </div>
        @error('captcha')
            <span style="color: red;">{{ $message }}</span>
        @enderror
    </div>

    <button type="submit">Submit</button>
</form>