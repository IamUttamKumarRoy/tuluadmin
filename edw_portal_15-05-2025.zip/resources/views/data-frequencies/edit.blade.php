@extends('layouts.app')

@section('content')
    <h1>Edit Data Frequency</h1>
    <form action="{{ route('data-frequencies.update', $dataFrequency->id) }}" method="POST">
        @csrf
        @method('PUT')
        <div>
            <label>Short Name:</label>
            <input type="text" name="short_name" value="{{ $dataFrequency->short_name }}" required>
        </div>
        <div>
            <label>Full Name:</label>
            <input type="text" name="full_name" value="{{ $dataFrequency->full_name }}" required>
        </div>
        <div>
            <label>Description:</label>
            <textarea name="description">{{ $dataFrequency->description }}</textarea>
        </div>
        <div>
            <label>Status ID:</label>
            <input type="number" name="status_id" value="{{ $dataFrequency->status_id }}">
        </div>
        <button type="submit">Update</button>
    </form>
@endsection