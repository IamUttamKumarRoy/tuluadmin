<!DOCTYPE html>
<html>
<head>
    <title>Laravel 12 File Upload</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2 class="mb-4">Laravel 12 File Upload</h2>
    
    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
        <img src="{{ asset('uploads/' . session('file')) }}" width="300">
    @endif

    <form action="{{ url('/upload') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="mb-3">
            <label class="form-label">Choose File:</label>
            <input type="file" name="file" class="form-control">
            @error('image')
                <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
        <button type="submit" class="btn btn-primary">Upload</button>
    </form>
</div>
</body>
</html>