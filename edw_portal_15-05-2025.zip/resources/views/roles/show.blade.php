@extends('layouts.app')

@section('content')
    <h1>Role Details</h1>
    <p><strong>Role ID:</strong> {{ $role->role_id }}</p>
    <p><strong>Name:</strong> {{ $role->name }}</p>
    <p><strong>Status ID:</strong> {{ $role->status_id }}</p>
    <a href="{{ route('roles.index') }}" class="btn btn-secondary">Back</a>
@endsection