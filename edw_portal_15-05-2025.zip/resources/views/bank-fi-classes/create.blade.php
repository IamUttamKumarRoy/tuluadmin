@extends('layouts.app')

@section('content')
    <h1>Create Bank FI Class</h1>
    <form action="{{ route('bank-fi-classes.store') }}" method="POST">
        @csrf
        <div>
            <label>FI Class ID:</label>
            <input type="number" name="fi_class_id" required>
        </div>
        <div>
            <label>FI Inst Type:</label>
            <input type="text" name="fi_inst_type" required>
        </div>
        <div>
            <label>FI Category:</label>
            <input type="text" name="fi_category" required>
        </div>
        <div>
            <label>FI Cluster:</label>
            <input type="text" name="fi_cluster" required>
        </div>
        <button type="submit">Create</button>
    </form>
@endsection
            