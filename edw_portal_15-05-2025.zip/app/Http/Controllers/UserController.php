<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Hash;
use App\Helpers\RitHelper;
use App\Models\User; 



class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        /*$users = User::latest()->paginate(10);
        return view('users.index', compact('users'));*/
        $users = User::latest()->paginate(20);
        //$users = User::paginate(10); // Paginate the User model, 10 items per page
        return view('users.index', compact('users'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }

    public function blockedUserlist()
    {
        $users = User::where('block', '=', 1)->paginate(10);
       
        return view('users.blocked_user', compact('users'));
    }

    public function inactiveUserlist()
    {
        $users = User::where('online', '=', 0)->paginate(10);
       
        return view('users.inactive_user', compact('users'));
    }

    public function adminUserList()
    {
        $users = User::where('role_id', '=', 104)->paginate(10);
       
        return view('users.admin_user', compact('users'));
    }

    public function activeUserList()
    {
        $users = User::where('online', '=', 1)->paginate(10);
       
        return view('users.active_user', compact('users'));
    }

    /**
     * Show the user's profile page.
     *
     * @return \Illuminate\View\View
     */
    public function profile()
    {
        $user = Auth::user(); // Get the currently authenticated user

        $logged_user_name      = $user->user_name;
        $logged_fi_id          = $user->fi_id;
        $bank_branch_id        = $user->bank_branch_id;

        $bank_fi   = RitHelper::getBankFi($logged_fi_id);
        $bank_name   = $bank_fi->fi_nm;
        //print_r($bank_name);

        $bank_branch = RitHelper::getBankBranch($bank_branch_id);
        $bank_branch_name   = $bank_branch->branch_name;

        $auth_user_str = "{$logged_user_name}";
        $auth_user_str = "{$logged_user_name}, {$bank_branch_name}, {$bank_name}";

        return view('users.profile', compact('user','bank_name','bank_branch_name'));
    }

}

