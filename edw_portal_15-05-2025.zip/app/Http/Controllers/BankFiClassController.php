<?php

namespace App\Http\Controllers;

use App\Models\BankFiClass;
use Illuminate\Http\Request;

class BankFiClassController extends Controller
{
    // Display a listing of the resource
    public function index()
    {
        $bankFiClasses = BankFiClass::all();
        return view('bank-fi-classes.index', compact('bankFiClasses'));
    }

    // Show the form for creating a new resource
    public function create()
    {
        return view('bank-fi-classes.create');
    }

    // Store a newly created resource in storage
    public function store(Request $request)
    {
        $request->validate([
            'fi_class_id' => 'required|integer',
            'fi_inst_type' => 'required|string|max:255',
            'fi_category' => 'required|string|max:255',
            'fi_cluster' => 'required|string|max:255',
        ]);

        BankFiClass::create($request->all());
        return redirect()->route('bank-fi-classes.index')->with('success', 'Bank FI Class created successfully.');
    }

    // Display the specified resource
    public function show(BankFiClass $bankFiClass)
    {
        return view('bank-fi-classes.show', compact('bankFiClass'));
    }

    // Show the form for editing the specified resource
    public function edit(BankFiClass $bankFiClass)
    {
        return view('bank-fi-classes.edit', compact('bankFiClass'));
    }

    // Update the specified resource in storage
    public function update(Request $request, BankFiClass $bankFiClass)
    {
        $request->validate([
            'fi_class_id' => 'required|integer',
            'fi_inst_type' => 'required|string|max:255',
            'fi_category' => 'required|string|max:255',
            'fi_cluster' => 'required|string|max:255',
        ]);

        $bankFiClass->update($request->all());
        return redirect()->route('bank-fi-classes.index')->with('success', 'Bank FI Class updated successfully.');
    }

    // Remove the specified resource from storage
    public function destroy(BankFiClass $bankFiClass)
    {
        $bankFiClass->delete();
        return redirect()->route('bank-fi-classes.index')->with('success', 'Bank FI Class deleted successfully.');
    }
}