<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RitFeature extends Model
{
    //protected $table      = 'tbl_rit_features'; // Specify the table name
   //protected $primaryKey = 'fi_id'; // Specify the primary key

    protected $fillable = [
        'rit_id',
        'rit_name',
        'rit_freq',
        'data_frequency_id',
        'rit_version',
        'no_of_col',
        'no_of_row',
        'cut_off_days',
        'dept',
        'department_id',
        'freq_full',
        'status', 
        'status_id', 
        'validate' 
    ];
}
