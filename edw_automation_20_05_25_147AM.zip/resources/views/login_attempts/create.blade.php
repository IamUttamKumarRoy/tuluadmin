@extends('layouts.app')

@section('content')
    <h1>Create New Login Attempt</h1>
    <form action="{{ route('login_attempts.store') }}" method="POST">
        @csrf
        <div class="form-group">
            <label for="user_id">User ID</label>
            <input type="text" name="user_id" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" name="password" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="ip_address">IP Address</label>
            <input type="text" name="ip_address" class="form-control">
        </div>
        <div class="form-group">
            <label for="user_agent">User Agent</label>
            <input type="text" name="user_agent" class="form-control">
        </div>
        <div class="form-group">
            <label for="success">Success</label>
            <select name="success" class="form-control" required>
                <option value="1">Yes</option>
                <option value="0">No</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
@endsection