@extends('layouts.app')

@section('content')
    <h1>Data Frequency Details</h1>
    <p><strong>Short Name:</strong> {{ $dataFrequency->short_name }}</p>
    <p><strong>Full Name:</strong> {{ $dataFrequency->full_name }}</p>
    <p><strong>Description:</strong> {{ $dataFrequency->description }}</p>
    <p><strong>Status ID:</strong> {{ $dataFrequency->status_id }}</p>
    <a href="{{ route('data-frequencies.index') }}" class="btn btn-secondary">Back</a>
@endsection