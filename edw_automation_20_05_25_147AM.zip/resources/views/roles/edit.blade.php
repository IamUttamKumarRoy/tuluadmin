@extends('layouts.app')

@section('content')
    <h1>Edit Role</h1>
    <form action="{{ route('roles.update', $role->id) }}" method="POST">
        @csrf
        @method('PUT')
        <div>
            <label>Role ID:</label>
            <input type="number" name="role_id" value="{{ $role->role_id }}" required>
        </div>
        <div>
            <label>Name:</label>
            <input type="text" name="name" value="{{ $role->name }}" required>
        </div>
        <div>
            <label>Status ID:</label>
            <input type="number" name="status_id" value="{{ $role->status_id }}" required>
        </div>
        <button type="submit">Update</button>
    </form>
@endsection