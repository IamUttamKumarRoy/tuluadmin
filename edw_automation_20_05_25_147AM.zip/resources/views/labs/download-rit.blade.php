<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Department Dropdown</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>

    <label for="department">Select Department:</label>
    <select id="department">
        <option value="">-- Select --</option>
        <option value="IT">IT</option>
        <option value="HR">HR</option>
        <option value="Finance">Finance</option>
    </select>

    <h3>Items under selected department:</h3>
    <ul id="items"></ul>

    <script>
        $(document).ready(function() {
            var departmentItems = {
                "IT": ["Laptop", "Server", "Router"],
                "HR": ["Employee Records", "Payroll System", "Recruitment Tools"],
                "Finance": ["Invoices", "Budget Reports", "Tax Documents"]
            };

            $("#department").change(function() {
                var selectedDept = $(this).val();
                var itemsList = $("#items");
                itemsList.empty();

                if (selectedDept && departmentItems[selectedDept]) {
                    departmentItems[selectedDept].forEach(function(item) {
                        itemsList.append("<li>" + item + "</li>");
                    });
                }
            });
        });
    </script>

</body>
</html>
