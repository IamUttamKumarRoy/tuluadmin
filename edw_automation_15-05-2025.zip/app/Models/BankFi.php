<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BankFi extends Model
{
    /** @use HasFactory<\Database\Factories\BankFiFactory> */
    use HasFactory;
	 
    protected $fillable = ['fi_id', 'fi_nm', 'fi_alias', 'geo_area_id', 'bank_fi_class_id'];

    /* 
	public function geoArea()
    {
        return $this->belongsTo(GeoArea::class, 'geo_area_id');
    }

    public function bankFiClass()
    {
        return $this->belongsTo(BankFiClass::class, 'bank_fi_class_id');
    } 
	*/
}
