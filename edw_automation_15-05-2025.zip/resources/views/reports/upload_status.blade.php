@extends('layouts.adminlte_3') 

@section('content')
 
<div class="container-fluid">
    <div class="row">
      <!-- left column -->
      <div class="col-md-12">
        <!-- jquery validation -->
        <form method="POST" action="{{ route('report.upload-status-rit') }}">
        @csrf
        <div class="card card-default" data-select2-id="46">
          <div class="card-header">
            <h3 class="card-title">Upload Status</h3>
          </div>
          
          <!-- /.card-header -->
          <div class="card-body">
            @if (session('success'))
                <div class="alert alert-success">
                    {{ session('success') }}
                </div>
            @endif

            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
            <div class="row" data-select2-id="44">
              <div class="col-md-6">
                <div class="form-group">
                  <label>RIT Name</label>                   
                    <select name="rit_id" id="ritId" class="form-control">
                        <option value="" disabled selected>RIT Name:</option> 
                        @foreach ($active_rits as $rit)
                            <option value="{{ $rit->rit_id }}">{{ $rit->rit_name }}</option>
                        @endforeach
                    </select>
                    @error('rit_id')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                <!-- /.form-group -->
                <div class="form-group">
                    <label for="uploadDateFrom" class="form-label">Upload Date From:</label>
                    <input type="text" name="upload_date_from" class="form-control datepickerClass" id="uploadDateFrom">
                    @error('upload_date_from')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                <!-- /.form-group -->
              </div>
              <!-- /.col -->
              <div class="col-md-6" data-select2-id="30">
                <div class="form-group" data-select2-id="29">                                    
                    <label for="bankFiId" class="form-label">Bank Name:</label>
                    <select name="bank_fi_id" id="bankFiId" class="form-control">
                        <option value="" disabled selected>Bank Name:</option> 
                        @foreach ($active_bank_fis as $bank_fi)
                            <option value="{{ $bank_fi->fi_id }}">{{ $bank_fi->fi_nm }}</option>
                        @endforeach
                    </select>
                    @error('bank_fi_id')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                <!-- /.form-group -->
                <div class="form-group">
                    <label for="uploadDateTo" class="form-label">Upload Date To:</label>
                    <input type="text" name="upload_date_to" class="form-control datepickerClass" id="uploadDateTo">
                    @error('upload_date_to')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                <!-- /.form-group -->
              </div>
               <div class="col-md-6" data-select2-id="30">
                <div class="form-group">
                    <label for="uploadDateFrom" class="form-label">Upload Date From:</label>
                    <input type="text" name="upload_date_from" class="form-control datepickerClass" id="uploadDateFrom">
                    @error('upload_date_from')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
               </div>
               <div class="col-md-6" data-select2-id="30">
                <div class="form-group">
                    <label for="uploadDateFrom" class="form-label">Upload Date From:</label>
                    <input type="text" name="upload_date_from" class="form-control datepickerClass" id="uploadDateFrom">
                    @error('upload_date_from')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
               </div>
              <!-- /.col -->
            </div>
            <!-- /.row -->

          </div>
          <!-- /.card-body -->
          <div class="card-footer">
            <button type="submit" class="btn btn-primary">Submit</button>
          </div>
        
        </div>
        <!-- /.card -->
        </form>
      </div>
      <!--/.col (left) -->
    </div>
    <!-- /.row -->
</div>

<?php 
 //echo "<pre>";
 //print_r($validated_data);
?>
    
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <!-- Main content -->
            <div class="invoice p-3 mb-3">
              
              <!-- Table row -->
              <div class="row">
                <div class="col-12 table-responsive">
                  <table class="table table-bordered">
                    <thead>
                    <tr>
                      <th>SL NO</th>
                      <th>BANK NAME</th>
                      <th>BRANCH NAME</th>
                      <th>FILE NAME</th>
                      <th>REPORTING DATE</th>
                      <th>UPLOAD DATE</th>
                      <th>PREPARED BY</th>
                      <th>PHONE NO</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach ($upload_status_data as $index => $data)
                    <tr>
                        <td>{{ $index + 1 }}</td>
                        <td>{{ $bankFiArray[$data->fi_id] }}</td> 
                        <td>{{ $bankBranchArray[$data->bank_branch_id] }}</td>  
                        <td>{{ $data->file_name }}</td>  
                        <td>{{ $data->base_date ? \Carbon\Carbon::parse($data->base_date)->format('Y-m-d') : '' }}</td>  
                        <td>{{ \Carbon\Carbon::parse($data->upload_time)->format('Y-m-d H:i:s') }}</td>  
                        <td>{{ $data->prepared_by }}</td>  
                        <td>{{ $data->phone_no }}</td>  
                    </tr>
                    @endforeach
                    </tbody>
                  </table>
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->


              <!-- this row will not appear when printing -->
              <div class="row no-print">
                <div class="col-12">
                <?php
                //echo "<pre>";
                //print_r($upload_status_data);
                ?>
                  <a href="#" rel="noopener" target="_blank" class="btn btn-default"><i class="fas fa-print"></i> Print</a>
                </div>
              </div>
            </div>
            <!-- /.invoice -->
        </div><!-- /.col -->
    </div><!-- /.row -->
</div> 
   
@endsection
