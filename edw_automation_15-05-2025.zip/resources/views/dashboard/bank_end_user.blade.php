@extends('layouts.adminlte_3')

@section('content')
    <h1>Bank End User Dashboard</h1>
     
@endsection
