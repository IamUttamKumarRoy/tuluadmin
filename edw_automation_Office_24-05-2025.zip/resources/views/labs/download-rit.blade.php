<!-- resources/views/roles/permissions.blade.php -->
@extends('layouts.adminlte_3') 

@section('content')

<div class="container-fluid">
    <div class="row">
        <div class="card bg-light d-flex flex-fill">
            <div class="card-header text-muted border-bottom-0">
                <h4><i class="icon fa fa-download"></i>Download Reference & Documentations</h4>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="bg-borders col-md-offset-6">         
                            <a class="btn-flat" style="font-size: medium" href="https://ereturns.bb.org.bd/cspcialregistration/pushFile/REFERENCE_FILE.zip/./ritUploads/reference" )'=""><b>Download Reference File </b></a><br>            
                        </div>
                        <div class="bg-borders col-md-offset-6">         
                            <a class="btn-flat" style="font-size: medium" href="https://ereturns.bb.org.bd/cspcialregistration/pushFile/UserGuide2.0.pdf/./ritUploads/Manual" )'=""><b>Download User Manual </b></a><br>            
                        </div> 
                        <div class="bg-borders col-md-offset-6">         
                            <a class="btn-flat" style="font-size: medium" href="https://ereturns.bb.org.bd/cspcialregistration/pushFile/End User Registration Form.zip/./ritUploads/Reg_form" )'=""><b>Download User Registration Form </b></a><br>            
                        </div> 

                        <div class="bg-borders col-md-offset-6">         
                            <a class="btn-flat" style="font-size: medium" href="https://ereturns.bb.org.bd/cspcialregistration/pushFile/RIT_User_Manual_02052023.zip/./ritUploads/ManualPSD" )'=""><b>RIT User Manual (PSD)</b></a><br>            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid">
    <div class="row">
        <div class="card bg-light d-flex flex-fill">
            <div class="card-header text-muted border-bottom-0">
                <h4><i class="icon fa fa-download"></i>Download RIT</h4>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <label for="department">Select Department:</label>
                        <select id="department">
                            <option value="">-- Select --</option>
                            <option value="IT">IT</option>
                            <option value="HR">HR</option>
                            <option value="Finance">Finance</option>
                        </select>
                        <ul id="items"></ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        var departmentItems = {
            "IT": ["Laptop", "Server", "Router"],
            "HR": ["Employee Records", "Payroll System", "Recruitment Tools"],
            "Finance": ["Invoices", "Budget Reports", "Tax Documents"]
        };

        $("#department").change(function() {
            var selectedDept = $(this).val();
            var itemsList = $("#items");
            itemsList.empty();

            if (selectedDept && departmentItems[selectedDept]) {
                departmentItems[selectedDept].forEach(function(item) {
                    itemsList.append("<li>" + item + "</li>");
                });
            }
        });
    });
</script>

@endsection