<!-- resources/views/roles/permissions.blade.php -->
@extends('layouts.adminlte_3') 

@section('content')

<div class="container-fluid">
    <div class="row">
        <div class="card bg-light d-flex flex-fill">
            <div class="card-header text-muted border-bottom-0">
                <h4><i class="icon fa fa-download"></i>Download Reference & Documentations</h4>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="bg-borders col-md-offset-6">                                     
                            <a class="btn-flat" href="{{ url('/download/reference/REFERENCE_FILE.zip') }}"><b>Download Reference File </b></a><br>            
                        </div>
                        <div class="bg-borders col-md-offset-6">      
                          <a class="btn-flat" href="{{ url('/download/Manual/UserGuide2.0.pdf') }}"><b>Download User Manual</b></a><br>                                        
                        </div> 
                        <div class="bg-borders col-md-offset-6">  
                          <a class="btn-flat" href="{{ url('/download/Reg_form/End User Registration Form.zip') }}"><b>Download User Registration Form </b></a><br>                                   
                        </div> 

                        <div class="bg-borders col-md-offset-6">   
                          <a class="btn-flat" href="{{ url('/download/ManualPSD/RIT_User_Manual_02052023.zip') }}"><b>RIT User Manual (PSD)</b></a>                                
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid">
    <div class="row">
        <div class="card bg-light d-flex flex-fill">
            <div class="card-header text-muted border-bottom-0">
                <h4><i class="icon fa fa-download"></i>Download RIT</h4>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <form>
                          @csrf
                          <label for="department">Download RIT By Department:</label>
                          
                          <select name="department" id="department" class="form-control">
                              <option value="">-- Select --</option>
                              @foreach ($departments as  $department)
                                  <option value="{{ $department->short_name }}">{{ $department->name }}</option>
                              @endforeach
                          </select>
                          
                        </form>
                      </div>                        
                        
                        <div id="items">

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<script>
    var baseDownloadUrl = "{{ url('/download') }}";
    var departmentItems = @json($dept_based_files);

    $(document).ready(function() {
        $("#department").change(function() {
            var selectedDept = $(this).val();
            var itemsContainer = $("#items");
            itemsContainer.empty();

            if (selectedDept && departmentItems[selectedDept]) {
                let tableHtml = '<table class="table table-bordered">';
                tableHtml += '<thead><tr><th style="width: 10px">Serial</th><th>Document Name</th><th>Download Link</th></tr></thead>';
                tableHtml += '<tbody>';

                departmentItems[selectedDept].forEach(function(item, index) {
                    const downloadUrl = baseDownloadUrl + '/' + selectedDept + '/' + encodeURIComponent(item);
                    
                    tableHtml += '<tr>';
                    tableHtml += '<td>' + (index + 1) + '</td>';
                    tableHtml += '<td>' + item + '</td>';
                    tableHtml += '<td><a href="' + downloadUrl + '" class="btn btn-info">Download</a></td>';
                    tableHtml += '</tr>';
                });

                tableHtml += '</tbody></table>';
                itemsContainer.html(tableHtml);
            }
        });
    });
</script>


@endsection