@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Edit Permission</div>

                <div class="card-body">
                    <form method="POST" action="{{ route('permissions.update', $permission->id) }}">
                        @csrf
                        @method('PUT')

                        <div class="form-group mb-3">
                            <label for="name">Name</label>
                            <input type="text" class="form-control @error('name') is-invalid @enderror" id="name" name="name" value="{{ old('name', $permission->name) }}" required>
                            @error('name')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <div class="form-group mb-3">
                            <label for="route_name">Route Name</label>
                            <input type="text" class="form-control @error('route_name') is-invalid @enderror" id="route_name" name="route_name" value="{{ old('route_name', $permission->route_name) }}">
                            @error('route_name')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <div class="form-group mb-3">
                            <label for="route_uri">Route URI</label>
                            <input type="text" class="form-control @error('route_uri') is-invalid @enderror" id="route_uri" name="route_uri" value="{{ old('route_uri', $permission->route_uri) }}">
                            @error('route_uri')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <div class="form-group mb-3">
                            <label for="route_action">Route Action</label>
                            <input type="text" class="form-control @error('route_action') is-invalid @enderror" id="route_action" name="route_action" value="{{ old('route_action', $permission->route_action) }}">
                            @error('route_action')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <div class="form-group mb-3">
                            <label for="action_method">Action Method</label>
                            <input type="text" class="form-control @error('action_method') is-invalid @enderror" id="action_method" name="action_method" value="{{ old('action_method', $permission->action_method) }}">
                            @error('action_method')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <div class="form-group mb-3">
                            <label for="http_method">HTTP Method</label>
                            <select class="form-control @error('http_method') is-invalid @enderror" id="http_method" name="http_method">
                                <option value="">Select Method</option>
                                <option value="GET" {{ old('http_method', $permission->http_method) == 'GET' ? 'selected' : '' }}>GET</option>
                                <option value="POST" {{ old('http_method', $permission->http_method) == 'POST' ? 'selected' : '' }}>POST</option>
                                <option value="PUT" {{ old('http_method', $permission->http_method) == 'PUT' ? 'selected' : '' }}>PUT</option>
                                <option value="PATCH" {{ old('http_method', $permission->http_method) == 'PATCH' ? 'selected' : '' }}>PATCH</option>
                                <option value="DELETE" {{ old('http_method', $permission->http_method) == 'DELETE' ? 'selected' : '' }}>DELETE</option>
                            </select>
                            @error('http_method')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <div class="form-group mb-3">
                            <label for="status_id">Status</label>
                            <select class="form-control @error('status_id') is-invalid @enderror" id="status_id" name="status_id">
                                <option value="1" {{ old('status_id', $permission->status_id) == 1 ? 'selected' : '' }}>Active</option>
                                <option value="0" {{ old('status_id', $permission->status_id) == 0 ? 'selected' : '' }}>Inactive</option>
                            </select>
                            @error('status_id')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <button type="submit" class="btn btn-primary">Update Permission</button>
                        <a href="{{ route('permissions.index') }}" class="btn btn-secondary">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection