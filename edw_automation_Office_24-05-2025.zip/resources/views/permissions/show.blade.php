@extends('layouts.adminlte_3') 

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Permission Details</div>

                <div class="card-body">
                    <div class="mb-3">
                        <strong>ID:</strong> {{ $permission->id }}
                    </div>
                    <div class="mb-3">
                        <strong>Name:</strong> {{ $permission->name }}
                    </div>
                    <div class="mb-3">
                        <strong>Route Name:</strong> {{ $permission->route_name ?? 'N/A' }}
                    </div>
                    <div class="mb-3">
                        <strong>Route URI:</strong> {{ $permission->route_uri ?? 'N/A' }}
                    </div>
                    <div class="mb-3">
                        <strong>Route Action:</strong> {{ $permission->route_action ?? 'N/A' }}
                    </div>
                    <div class="mb-3">
                        <strong>Action Method:</strong> {{ $permission->action_method ?? 'N/A' }}
                    </div>
                    <div class="mb-3">
                        <strong>HTTP Method:</strong> {{ $permission->http_method ?? 'N/A' }}
                    </div>
                    <div class="mb-3">
                        <strong>Status:</strong> {{ $permission->status_id ? 'Active' : 'Inactive' }}
                    </div>
                    <div class="mb-3">
                        <strong>Created At:</strong> {{ $permission->created_at->format('Y-m-d H:i:s') }}
                    </div>
                    <div class="mb-3">
                        <strong>Updated At:</strong> {{ $permission->updated_at->format('Y-m-d H:i:s') }}
                    </div>

                    <div class="d-flex">
                        <a href="{{ route('permissions.edit', $permission->id) }}" class="btn btn-primary me-2">Edit</a>
                        <form action="{{ route('permissions.destroy', $permission->id) }}" method="POST">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection