<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>EDW User Registration</title>
    <meta name="csrf-token" content="{{ csrf_token() }}"> 
    <link href="{{ asset('assets/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <link rel="stylesheet" href="{{ asset('assets/font/bootstrap-icons.css') }}">
    <style> 
    .border-green3
    {
        border: 3px solid #73AD21;
    }
    .formHeading
    {
        font-family: Castellar, sans-serif;
        font-size: 25px;
        color: #B00000;
        text-align: center;
        text-decoration: underline;
        size: portrait;
    } 
    #userForm
    {
        /*display:none;*/
    }
    #branchForm
    {
        
    }
    #reportType
    {
        display:none;
    }
    #sbsForm
    {
        display:none;
    }
    </style>
  </head>
  <body>

  <div class="container">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-xl-6">
        <div class="card rounded-3 text-black border-green3">
            <form method="POST" action="{{ route('edw.register-post') }}">
            <div class="card-header">                
                <h1 class="formHeading text-center"> Registration Form</h1>
            </div>
            <div class="card-body">                
                @csrf
                @if (session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                @endif

                @if ($errors->any())
                    <div class="alert alert-danger">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif
                    <div class="form-group">                        
                        <label for="fiId">Bank / NBFI Name <span class="text-danger">*</span></label>                         
                        <select name="fi_id" id="fiId" class="form-control select2">
                            <option value="">---Select---</option>
                            @foreach ($active_bank_fis as $bank_fi)
                                <option value="{{ $bank_fi->fi_id }}">{{ $bank_fi->fi_nm }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="form-group" id="reportType">
                        <label class="form-label">Choose Report Type</label>
                        <div class="form-check">
                            <input class="input-sm form-check-input" type="radio" name="reportFor" id="iss" value="iss" checked>
                            <label class="form-check-label" for="iss">Branch End User</label>
                        </div>
                        <div class="form-check">
                            <input class="input-sm form-check-input" type="radio" name="reportFor" id="edw" value="edw">
                            <label class="form-check-label" for="edw">Head Office End User</label>
                        </div>
                    </div>
                    <div id="userExists"></div>
                    <div class="form-group" id="branchForm">
                        <label for="bankBranchId" class="col-form-label">Branch Name <span color="red">*</font></label>
                        <div class="">                            
                            <select class="form-control" name="bank_branch_id" id="bankBranchId">
                                <option value="">Select Branch</option>
                            </select>
                        </div>
                    </div>
                     
                    <div class="mb-3" id="sbsForm">
                        <label class="form-label">SBS Code <span class="text-danger">*</span></label>
                        <input type="text" class="form-control form-control-sm" name="sbs_code" id="sbsCode">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">User Id<span class="text-danger">*</span></label>
                        <input type="text" class="form-control form-control-sm" name="user_id" id="userId">
                    </div>
                    <div id="userForm" >
                        <div class="mb-3">
                            <label class="form-label">Employee Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control form-control-sm text-uppercase" name="user_name">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Password <span class="text-danger">*</span></label>
                            <input type="password" class="form-control form-control-sm" name="password">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Re-Type Password <span class="text-danger">*</span></label>
                            <input type="password" class="form-control form-control-sm" name="password_confirmation">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Designation <span class="text-danger">*</span></label>
                            <input type="text" class="form-control form-control-sm text-uppercase" name="designation">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Department/Desk<span class="text-danger">*</span></label>
                            <input type="text" class="form-control form-control-sm text-uppercase" name="dept_sec_desk">
                        </div>                        

                        <div class="mb-3">
                            <label class="form-label">Email <span class="text-danger">*</span></label>
                            <input type="email" class="form-control form-control-sm" name="email">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Mobile No. <span class="text-danger">*</span></label>
                            <input type="tel" class="form-control form-control-sm" name="cell">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Phone No. <span class="text-danger">*</span></label>
                            <input type="text" class="form-control form-control-sm" name="phone">
                        </div>

                        <!-- CAPTCHA Field -->
                        <div class="mb-3">                          
                            <img src="{{ url('captcha') }}" alt="Captcha" class="captcha-image img-fluid mb-2">
                            <label for="captcha" class="form-label text-first"><b>Enter the text from the image above</b></label>
                            <input type="text" name="captcha" class="form-control" id="captcha" placeholder="Insert the word above">
                        </div>
                    </div>

                
            </div>
            <div class="card-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
            </form>
        </div>
      </div>
    </div>
  </div>
<!-- </section> -->
    <script src="{{ asset('assets/bootstrap/js/bootstrap.bundle.min.js') }}" ></script>
    <script src="{{ asset('assets/js/jquery.min.js') }}" ></script>
    

    <script>

$( function() {

    $("#edw").change(function() {
        $("#userForm").show();
        $("#sbsForm").hide();
        $("#branchForm").hide();
    });

    $("#iss").change(function() {
        $("#userForm").hide();
        $("#branchForm").show();
    });

    $('#fiId').change(function() {

        var bankId = $(this).val();

        if (bankId) 
        {
            $.ajax({
                url: '{{ route('ajax.get-branches-by-bank') }}', 
                type: 'POST',
                data: { fi_id: bankId },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') // Ensure CSRF protection
                },
                success: function(response) {
                    $('#bankBranchId').empty().append('<option value="">Select Branch</option>');

                    $.each(response, function(fi_branch_id, branch_name) {
                        $('#bankBranchId').append('<option value="' + fi_branch_id + '">' + branch_name + '</option>');
                    });
                    $('#reportType').show();                    
                },
                error: function() {
                    alert('Error fetching branches.');
                }
            });
        } else {
            $('#bankBranchId').empty().append('<option value="">Select Branch</option>');
        }
    });


    $("#bankBranchId").change(function() {
        $("#userForm").hide();
        $("#sbsForm").show();
    });

    $("#sbsCode").on("blur", function() 
    {
        var sbs_code = $(this).val();
        $.ajax({
            url: "{{ route('sbs_code.user_limit_check') }}",
            type: "GET",
            data: { sbs_code: sbs_code },
            success: function(response) 
            {
                $("#userExists").hide();
                if (response.exists) {
                    $("#userExists").html("<span class='text-danger'>User already exists!</span>");
                    $("#userForm").hide();
                } else {
                    $("#userExists").html("<span class='text-success'>Username available.</span>");                    
                    $("#userForm").show();
                }
            }
        });
    });
    /*
    $('#bankBranchId').change(function() {
        var bankId   = $('#fiId').val();
        var branchId = $(this).val();

        if (bankId && branchId) {
            $.ajax({
                url: '{{ route('ajax.get-user-id') }}',
                type: 'POST',
                data: { fi_id: bankId, bank_branch_id: branchId },
                headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                success: function(response) {
                    $('#userId').val(response.user_id); // Set User ID in input field
                },
                error: function() {
                    alert('Error generating user ID.');
                }
            });
        }
    });
    */
});

</script>

  </body>
</html>

