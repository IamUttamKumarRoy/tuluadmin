@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Create RIT Feature</h1>
	@if ($errors->any())
		<div class="alert alert-danger">
			<ul>
				@foreach ($errors->all() as $error)
					<li>{{ $error }}</li>
				@endforeach
			</ul>
		</div>
	@endif
    <form action="{{ route('rit-features.store') }}" method="POST">
        @csrf
        <div class="form-group">
            <label for="rit_id">RIT ID</label>
            <input type="number" name="rit_id" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="rit_name">Name</label>
            <input type="text" name="rit_name" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="rit_freq">Frequency</label>
            <input type="text" name="rit_freq" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="rit_version">Version</label>
            <input type="number" name="rit_version" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="no_of_col">Number of Columns</label>
            <input type="number" name="no_of_col" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="no_of_row">Number of Rows</label>
            <input type="number" name="no_of_row" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="cut_off_days">Cut-off Days</label>
            <input type="number" name="cut_off_days" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="dept">Department</label>
            <input type="text" name="dept" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="status">Status</label>
            <input type="text" name="status" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="status">StatusId</label>
            <input type="text" name="status_id" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="validate">Validate</label>
            <input type="number" name="validate" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Create</button>
    </form>
</div>
@endsection