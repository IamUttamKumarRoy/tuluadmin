<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Session;

use Illuminate\Support\Facades\View; // Import the View facade
use Illuminate\Support\Facades\Auth; // Import the Auth facade
use App\Helpers\RitHelper;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        Validator::extend('captcha', function ($attribute, $value, $parameters, $validator) {
            return strtolower($value) === Session::get('captcha');
        });

        Validator::replacer('captcha', function ($message, $attribute, $rule, $parameters) {
            return __('The captcha you entered does not match the image.');
        });

        // --- Share Auth Variables based on login status ---
        // This closure will be executed for every request.
        // We use Auth::check() to determine if a user is logged in.
        View::composer('*', function ($view) { // The '*' means this composer applies to ALL views
            if (Auth::check()) 
            {
                $user = Auth::user();
                
                $logged_user_name      = $user->user_name;
                $logged_fi_id          = $user->fi_id;
                $bank_branch_id        = $user->bank_branch_id;
                $user_role_id          = $user->role_id;

                $bank_fi   = RitHelper::getBankFi($logged_fi_id);
                $bank_name   = $bank_fi->fi_nm;


                $bank_branch = RitHelper::getBankBranch($bank_branch_id);
                $bank_branch_name   = $bank_branch->branch_name;

                $auth_user_str = "{$logged_user_name}";
                $auth_user_str = "{$logged_user_name}, {$bank_branch_name}, {$bank_name}";

                $user_permitted_route_list = RitHelper::getRoleBasedRoute($user_role_id);
                // User is logged in
                $view->with('logged_user_name', $logged_user_name);  
                $view->with('logged_fi_id', $logged_fi_id);
                $view->with('bank_branch_id', $bank_branch_id);
                $view->with('user_role_id', $user_role_id);
                $view->with('bank_fi', $bank_fi);
                $view->with('bank_name', $bank_name);
                $view->with('bank_branch_name', $bank_branch_name);
                $view->with('auth_user_str', $auth_user_str);
                $view->with('user_permitted_route_list', $user_permitted_route_list);

                $view->with('loggedInUser', Auth::user()); // Share the entire User model instance
                $view->with('isAuthenticated', true);       // A boolean flag
                $view->with('userName', Auth::user()->name); // Specific user name
                $view->with('userId', Auth::user()->id);     // Specific user ID
                $view->with('global_var_test', 'Global Var');     
            } else {
                // User is not logged in
                $view->with('loggedInUser', null);
                $view->with('isAuthenticated', false);
                $view->with('userName', null);
                $view->with('userId', null);
                $view->with('global_var_test', 'Global Var'); 
                                $view->with('logged_user_name', $logged_user_name);  
                $view->with('logged_fi_id', null);
                $view->with('bank_branch_id', null);
                $view->with('user_role_id', null);
                $view->with('bank_fi', null);
                $view->with('bank_name', null);
                $view->with('bank_branch_name', null);
                $view->with('auth_user_str', null);
                $view->with('user_permitted_route_list', null);   
                
            }
        });

        // Alternatively, you could use View::share() directly if you prefer,
        // but View::composer('*', function(){...}) is slightly more idiomatic
        // for conditional logic that runs for every view.
        // The difference is minimal for this specific use case.
        // Example using View::share() directly:
        /*
        View::share('isAuthenticated', Auth::check());
        View::share('loggedInUser', Auth::user()); // This will be null if not logged in
        View::share('userName', Auth::user() ? Auth::user()->name : null);
        View::share('userId', Auth::user() ? Auth::user()->id : null);
        */

        Paginator::useBootstrap();
    }
}
