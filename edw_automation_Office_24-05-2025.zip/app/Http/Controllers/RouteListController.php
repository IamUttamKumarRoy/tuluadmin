<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

class RouteListController extends Controller
{
    public function index()
    {
        $routes = Route::getRoutes();
        $routeDetails = [];

        foreach ($routes as $route) {
            $routeDetails[] = [
                'method' => implode('|', $route->methods()),
                'uri' => $route->uri(),
                'name' => $route->getName(),
                'action' => $route->getActionName(),
            ];
            dd($route);
            break;
        }

        // You can now pass this $routeDetails array to a view or return it as JSON
        return view('route-list', ['routes' => $routeDetails]);
        // Or:
        // return response()->json($routeDetails);
    }
}