<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\BankBranch;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use League\Csv\Reader;

class BankBranchController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
    /**
     * Show the form for creating a new resource.
     */
    public function importBranch()
    {
        $test_var = '';
       
        return view('bank-branches.import-branch', compact('test_var'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function importBranchPost(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'csv_file' => 'required|mimes:csv,txt',
        ]);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }

        $file = $request->file('csv_file');

        try {
            $csv = Reader::createFromPath($file->getPathname(), 'r');
            $csv->setHeaderOffset(0); // Assuming the first row of your CSV contains headers

            $insertedCount = 0;
            $skippedCount = 0;

            DB::beginTransaction();

            foreach ($csv->getRecords() as $record) {
                $fiBranchId = $record['fi_branch_id'] ?? null;
                $fiId = $record['fi_id'] ?? null;
                $branchName = $record['branch_name'] ?? null;
                $division = $record['division'] ?? null;
                $district = $record['district'] ?? null;
                $thana = $record['thana'] ?? null;
                $statusId = $record['status_id'] ?? null;

                // Ensure required fields are present
                if (!isset($fiBranchId) || !isset($fiId)) {
                    continue; // Skip if essential fields are missing
                }

                // Check if a record with this fi_branch_id already exists
                $exists = BankBranch::where('fi_branch_id', $fiBranchId)->exists();

                if (!$exists) {
                    BankBranch::create([
                        'fi_branch_id' => $fiBranchId,
                        'fi_id' => $fiId,
                        'branch_name' => $branchName,
                        'division' => $division,
                        'district' => $district,
                        'thana' => $thana,
                        'status_id' => $statusId,
                        'created_at' => now(),
                        'updated_at' => now(),
                    ]);
                    $insertedCount++;
                } else {
                    $skippedCount++;
                }
            }

            DB::commit();

            return redirect()->route('import.import-branch')->with('success', "Successfully imported {$insertedCount} records. {$skippedCount} records were skipped due to existing `fi_branch_id`.");

        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()->withErrors(['error' => 'Error processing CSV file: ' . $e->getMessage()])->withInput();
        }
    }
}
