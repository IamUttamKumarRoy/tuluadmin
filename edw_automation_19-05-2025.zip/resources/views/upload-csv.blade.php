<!DOCTYPE html>
<html>
<head>
    <title>Upload CSV</title>
</head>
<body>
    <h1>Upload CSV File</h1>
    @if (session('success'))
        <div style="color: green;">{{ session('success') }}</div>
    @endif
    <form action="{{ route('upload-csv') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <label for="csv_file">CSV File:</label>
        <input type="file" name="csv_file" id="csv_file" required>
        <br>
        <button type="submit">Upload</button>
    </form>
</body>
</html>