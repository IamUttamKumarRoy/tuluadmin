@extends('layouts.adminlte_3') 

@section('content')
     
<div class="card bg-light d-flex flex-fill">
    <div class="card-header text-muted border-bottom-0">
      <h1>Import Bank Branches from CSV</h1>
    </div>
    <div class="card-body pt-0">
      

    @if (session('success'))
        <div style="color: green;">{{ session('success') }}</div>
    @endif

    @if ($errors->any())
        <div style="color: red;">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('import.import-branch-post') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div>
            <label for="csv_file">Select CSV File:</label>
            <input type="file" name="csv_file" id="csv_file" accept=".csv" required>
        </div>
        <button type="submit">Import</button>
    </form>
    </div>
    <div class="card-footer">
      <div class="text-right">
        <!-- <a href="#" class="btn btn-sm bg-teal">
          <i class="fas fa-comments"></i>
        </a>
        <a href="#" class="btn btn-sm btn-primary">
          <i class="fas fa-user"></i> View Profile
        </a> -->
      </div>
    </div>
</div>    


@endsection
