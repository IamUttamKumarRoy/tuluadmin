<!DOCTYPE html>
<html>
<head>
    <title>View Status</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>View Status</h1>
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">{{ $status->name }}</h5>
                <p class="card-text">{{ $status->detail }}</p>
                <p class="card-text"><strong>Sorting Order:</strong> {{ $status->sorting_order }}</p>
                <p class="card-text"><strong>Terminal:</strong> {{ $status->terminal }}</p>
                <p class="card-text"><strong>Browser:</strong> {{ $status->browser }}</p>
                <a href="{{ route('status.edit', $status->id) }}" class="btn btn-warning">Edit</a>
                <form action="{{ route('status.destroy', $status->id) }}" method="POST" style="display:inline;">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </div>
        </div>
        <a href="{{ route('status.index') }}" class="btn btn-secondary mt-3">Back to List</a>
    </div>
</body>
</html>