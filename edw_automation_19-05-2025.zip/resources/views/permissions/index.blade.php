@extends('layouts.adminlte_3') 

@section('content')
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex justify-content-between">
                        <h2>Permissions</h2>
                        <a href="{{ route('permissions.create') }}" class="btn btn-primary">Create Permission</a>
                    </div>
                </div>

                <div class="card-body">
                    @if (session('success'))
                        <div class="alert alert-success" role="alert">
                            {{ session('success') }}
                        </div>
                    @endif

                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Route Name</th>                                
                                <th>Route Uri</th>
                                <th>Route Action</th>
                                <th>Route Controller</th>
                                <th>Route method</th>
                                <th>HTTP Method</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $inc = 1;?>
                            @foreach ($permissions as $permission)
                            <tr>
                                <td>{{ $inc++ }}</td>
                                <td>{{ $permission->name }}</td>
                                <td>{{ $permission->route_name }}</td>
                                <td>{{ $permission->route_uri }}</td>
                                <td>{{ $permission->route_action }}</td>
                                <td>{{ $permission->action_controller }}</td>
                                <td>{{ $permission->action_method }}</td>
                                <td>{{ $permission->http_method }}</td>
                                <td>{{ $permission->status_id ? 'Active' : 'Inactive' }}</td>
                                <td>
                                    <a href="{{ route('permissions.show', $permission->id) }}" class="btn btn-info btn-sm">View</a>
                                    <a href="{{ route('permissions.edit', $permission->id) }}" class="btn btn-primary btn-sm">Edit</a>
                                   
                                    
                                    <form action="{{ route('permissions.destroy', $permission->id) }}" method="POST" style="display: inline;">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</button>
                                    </form>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>

                    {{ $permissions->links() }}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection