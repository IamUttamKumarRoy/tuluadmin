<?php 
// Custom Class import
use Illuminate\Support\Facades\Auth;
use App\Helpers\RitHelper;
$user = Auth::user();

  //print_r($user);

  $logged_user_name      = $user->user_name;
  $logged_fi_id          = $user->fi_id;
  $bank_branch_id        = $user->bank_branch_id;

  $bank_fi   = RitHelper::getBankFi($logged_fi_id);
  $bank_name   = $bank_fi->fi_nm;
  

  $bank_branch = RitHelper::getBankBranch($bank_branch_id);
  $bank_branch_name   = $bank_branch->branch_name;

  $auth_user_str = "{$logged_user_name}";
  $auth_user_str = "{$logged_user_name}, {$bank_branch_name}, {$bank_name}";
?>
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>@yield('title', 'eReturn Portal')</title>
  <meta name="csrf-token" content="{{ csrf_token() }}">  
  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="{{ asset('assets/plugins/fontawesome-free/css/all.min.css') }}">
  <!-- daterange picker -->
  <link rel="stylesheet" href="{{ asset('assets/plugins/daterangepicker/daterangepicker.css') }}">
  <!-- Theme style -->
  <link rel="stylesheet" href="{{ asset('assets/dist/css/adminlte.min.css') }}">
  <!-- Select2 -->
  <link rel="stylesheet" href="{{ asset('assets/plugins/select2/css/select2.min.css') }}">
  <link rel="stylesheet" href="{{ asset('assets/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css') }}">

  <!-- jQuery -->
  <script src="{{ asset('assets/plugins/jquery/jquery.min.js') }}"></script>
  <!-- Bootstrap 4 -->
  <script src="{{ asset('assets/plugins/bootstrap/js/bootstrap.bundle.min.js') }}"></script>

  <!-- Select2 -->
  <script src="{{ asset('assets/plugins/select2/js/select2.full.min.js') }}"></script>

  <script src="{{ asset('assets/plugins/moment/moment.min.js') }}"></script>
  <!-- date-range-picker -->
  <script src="{{ asset('assets/plugins/daterangepicker/daterangepicker.js') }}"></script>

  <!-- dropzonejs -->
  <script src="{{ asset('assets/plugins/dropzone/min/dropzone.min.js') }}"></script>

  <!-- AdminLTE App -->
  <script src="{{ asset('assets/dist/js/adminlte.min.js') }}"></script>
</head>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      
      <!-- User profile Dropdown Menu -->
      <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#">
          <i class="fas fa-user-cog fa-fw"></i>          
          <?php echo $auth_user_str;?>
        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          
          <div class="dropdown-divider"></div>
          <a href="{{ route('users.profile') }}" class="dropdown-item">
            <i class="fas fa-user-circle"></i> Profile             
          </a>


          <div class="dropdown-divider"></div>
          <a href="{{ route('change.password.get') }}" class="dropdown-item">
            <i class="fa fa-key"></i> Change Password            
          </a> 
          <div class="dropdown-divider"></div>

          <a href="{{ route('logout') }}" class="dropdown-item dropdown-footer"><i class="fas fa-sign-out-alt fa-fw"></i> Logout</a>
        </div>
      </li>      
    </ul> 
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="{{ route('dashboard') }}" class="brand-link">
      <img src="{{ asset('assets/images/bb-logo.png') }}" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
      <span class="brand-text font-weight-light">eReturn</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      
      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item">
            <a href="{{ route('dashboard') }}" class="nav-link">
              <i class="nav-icon fas fa-home"></i>
              <p>Home</p>
            </a>
          </li>                    
          <li class="nav-item">
            <a href="{{ route('users.index') }}" class="nav-link">
              <i class="nav-icon fas fa-users fa-fw"></i>
              <p>All User List</p>
            </a>
          </li>  
          <li class="nav-item">
            <a href="{{ route('rit-submissions.index') }}" class="nav-link">
              <i class="nav-icon fas fa-upload fa-fw"></i>
              <p>Upload Status</p>
            </a>
          </li> 
          <li class="nav-item">
            <a href="{{ route('report.upload-status') }}" class="nav-link">
              <i class="nav-icon fas fa-copy"></i>
              <p>
                Reports
                <i class="fas fa-angle-left right"></i>                
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="{{ route('report.upload-status') }}" class="nav-link">
                  <i class="fas fa-angle-double-right fa-fw"></i>
                  <p>Upload Status(RIT &amp; Base_date wise)</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="{{ route('report.upload-status-rit') }}" class="nav-link">
                  <i class="fas fa-angle-double-right fa-fw"></i>
                  <p>Upload Status(RIT &amp; Bank wise)</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="{{ route('report.non-reporting-branches') }}" class="nav-link">
                  <i class="fas fa-angle-double-right fa-fw"></i>
                  <p>Non Reporting Bank/Branch</p> 
                </a>
              </li> 
            </ul>
          </li>  
          <li class="nav-item">
            <a href="{{ route('rit-features.index') }}" class="nav-link"> 
              <i class="nav-icon fas fa-external-link-square-alt fa-fw"></i>
              <p>RIT Details</p>
            </a>
          </li>  
          <li class="nav-item">
            <a href="{{ route('import.import-branch') }}" class="nav-link">
              <i class="nav-icon fas fa-external-link-square-alt fa-fw"></i>
              <p>Upload Branch List</p>
            </a>
          </li>   
          <li class="nav-item">
            <a href="{{ route('rit.download-rit') }}" class="nav-link">                     
            <i class="nav-icon fas fa-download fa-fw"></i>                   
              <p>Download RIT</p> 
            </a>
          </li>  
          <li class="nav-item">
            <a href="{{ route('contact') }}" class="nav-link">                                        
            <i class="nav-icon fa fa-address-book"></i>                   
              <p>Contact Info</p> 
            </a>
          </li>
          <li class="nav-item">
            <a href="{{ route('change.password.get') }}" class="nav-link">                                        
            <i class="nav-icon fa fa-key"></i>                   
              <p>Change Password</p>
            </a>
          </li>  
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-user-plus fa-fw"></i>
              <p> Add User
                <i class="fas fa-angle-left right"></i>                
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="{{ route('users.add-md') }}" class="nav-link">
                  <i class="fas fa-angle-double-right fa-fw"></i>
                  <p>Add MD/CEO User</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="../layout/top-nav-sidebar.html" class="nav-link">
                  <i class="fas fa-angle-double-right fa-fw"></i>
                  <p>Add Head Office Admin User</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="../layout/boxed.html" class="nav-link">
                  <i class="fas fa-angle-double-right fa-fw"></i>
                  <p>BB End User</p>
                </a>
              </li> 
            </ul>
          </li>  
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-user-friends fa-fw"></i>
              <p>User List <i class="fas fa-angle-left right"></i></p>
            </a> 
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="{{ route('users.admin_userlist') }}" class="nav-link">
                  <i class="fas fa-user-tie fa-fw"></i>
                  <p>Admin User</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="{{ route('users.active_userlist') }}" class="nav-link">
                  <i class="fas fa-user-check"></i>
                  <p>Active</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="{{ route('users.inactive_userlist') }}" class="nav-link">
                  <i class="fas fa-user-clock"></i>
                  <p>Inactive</p>
                </a>
              </li> 
              <li class="nav-item">
                <a href="{{ route('users.blocked_userlist') }}" class="nav-link">
                  <i class="fas fa-user-lock"></i>
                  <p>Block</p>
                </a>
              </li> 
            </ul>
          </li>                                                                                                       
          <!--<li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon far fa-circle text-info"></i>
              <p>Informational</p>
            </a>
          </li>-->
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">            
            @yield('content_header')
          </div>
          <!-- <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Blank Page</li>
            </ol>
          </div> -->
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

        @yield('content')

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Developed By</b> Information and Communication Technology Department
    </div>
    <strong>&copy; {{ date('Y') }} - Bangladesh Bank
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->



<script>
  $( function() {

    $('.datepickerClass').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      minYear: 1901,
      maxYear: parseInt(moment().format('YYYY'),10)
    });

    //$('.select2').select2({
    //});

  });
  </script>

</body>
</html>
