<!DOCTYPE html>
<html>
<head>
    <title>Import Excel File</title>
</head>
<body>
    @if ($message = Session::get('success'))
        <p style="color: green;">{{ $message }}</p>
    @endif

    <form action="{{ route('import') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <input type="file" name="file" required>
        <button type="submit">Import Excel</button>
    </form>
</body>
</html>