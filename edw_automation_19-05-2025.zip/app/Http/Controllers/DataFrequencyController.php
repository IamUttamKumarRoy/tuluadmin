<?php

namespace App\Http\Controllers; 

use App\Models\DataFrequency;
use Illuminate\Http\Request;

class DataFrequencyController extends Controller
{
    // Display a listing of the resource
    public function index()
    {
        $dataFrequencies = DataFrequency::all();
        return view('data-frequencies.index', compact('dataFrequencies'));
    }

    // Show the form for creating a new resource
    public function create()
    {
        return view('data-frequencies.create');
    }

    // Store a newly created resource in storage
    public function store(Request $request)
    {
        $request->validate([
            'short_name' => 'required|string|max:250',
            'full_name' => 'required|string|max:250',
            'description' => 'nullable|string',
            'status_id' => 'nullable|integer',
        ]);

        DataFrequency::create($request->all());
        return redirect()->route('data-frequencies.index')->with('success', 'Data Frequency created successfully.');
    }

    // Display the specified resource
    public function show(DataFrequency $dataFrequency)
    {
        return view('data-frequencies.show', compact('dataFrequency'));
    }

    // Show the form for editing the specified resource
    public function edit(DataFrequency $dataFrequency)
    {
        return view('data-frequencies.edit', compact('dataFrequency'));
    }

    // Update the specified resource in storage
    public function update(Request $request, DataFrequency $dataFrequency)
    {
        $request->validate([
            'short_name' => 'required|string|max:250',
            'full_name' => 'required|string|max:250',
            'description' => 'nullable|string',
            'status_id' => 'nullable|integer',
        ]);

        $dataFrequency->update($request->all());
        return redirect()->route('data-frequencies.index')->with('success', 'Data Frequency updated successfully.');
    }

    // Remove the specified resource from storage
    public function destroy(DataFrequency $dataFrequency)
    {
        $dataFrequency->delete();
        return redirect()->route('data-frequencies.index')->with('success', 'Data Frequency deleted successfully.');
    }
}