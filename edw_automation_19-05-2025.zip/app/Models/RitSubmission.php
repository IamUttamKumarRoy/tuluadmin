<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RitSubmission extends Model
{
    /** @use HasFactory<\Database\Factories\RitSubmissionFactory> */
    use HasFactory;
	
	 protected $fillable = [
        'rit_id',
        'fi_id',
        'bank_branch_id',
        'user_id',
        'data_frequency_id',
        'file_name',
        'base_date',
        'phone_no',
        'prepared_by',
        'upload_time',
        'status_id',
        'ip_address',
        'user_agent',
    ];
}
