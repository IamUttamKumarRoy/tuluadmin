<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

// Custom Class import
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Carbon\Carbon;
use App\Helpers\RitHelper;

// Model import 
use App\Models\User;
use App\Models\BankFiClass;
use App\Models\BankFi;
use App\Models\BankBranch;
use App\Models\DataFrequency;
use App\Models\Department;
use App\Models\RitFeature;
use App\Models\RitSubmission;

class RitSubmissionController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        /*$users = User::latest()->paginate(10);
        return view('users.index', compact('users'));*/
        $rit_submissions = RitSubmission::latest()->paginate(10);
        //$users = User::paginate(10); // Paginate the User model, 10 items per page
        return view('rit-submissions.index', compact('rit_submissions'));
    }
    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function downloadRit()
    {                   
        $test_var = '';

        $departments = Department::all();


        //$files = File::files(public_path('ritUploads/STAT'));

        $dept_based_files = [];

        foreach ($departments as $department) {
            //echo $department->name ."<==>".$department->short_name. "<br>";

            if( !empty($department->short_name) ) 
            {
                $department_shortname = $department->short_name;
                $dept_based_files[$department_shortname] = [];

                $folderPath = public_path('ritUploads/'.$department_shortname);

                if (File::exists($folderPath) && File::isDirectory($folderPath)) {
                    $files = File::files($folderPath);
                    foreach ($files as $file) {
                        //echo $file->getFilename() . "<br>";
                        $dept_based_files[$department_shortname][] = $file->getFilename();
                    }
                } /*else {
                    echo "Folder does not exist.";
                }*/
    
            }
        }
        //echo "<pre>";
        //print_r($dept_based_files);
        //return view('rit-submissions.download-rit', compact('test_var'));  
        return view('rit-submissions.download-rit', compact('test_var','departments','dept_based_files'));                         
    }
    public function downloadFile($department,$filename)
    {                   
        $filePath = public_path('ritUploads/'.$department.'/'. $filename);
        return response()->download($filePath);                        
    }

    public function getFrequency($data_frequency_id)
    {
        $options = RitFeature::where('data_frequency_id', $data_frequency_id)->get();
        return response()->json($options);
    }

     // Accept the Request object
    public function getBranchesByBank(Request $request)
    {
        // Get the bank_id from the request body
        $fi_id = $request->input('fi_id'); // Use input() to get data from POST body

        // You might want to add validation here to ensure $bankId is valid
        if (empty($fi_id)) {
             return response()->json([], 400); // Return empty array and a bad request status if no ID
        }

        $branches = BankBranch::where('fi_id', $fi_id)->pluck('branch_name', 'fi_branch_id');

        // Return the branches as a JSON response
        return response()->json($branches);
    }

    public function getUserCount(Request $request)
    {
        $fi_id          = $request->input('fi_id');
        $bank_branch_id = $request->input('bank_branch_id');

        $user_count = User::where('fi_id', $fi_id)
                        ->where('bank_branch_id', $bank_branch_id)
                        ->count();

        $new_count = $user_count + 1; // Increment user count

        //$user_id = $fi_id . '-' . $bank_branch_id . '-' . str_pad($new_count, 2, '0', STR_PAD_LEFT);
        $user_id = $bank_branch_id . '-' . str_pad($new_count, 2, '0', STR_PAD_LEFT);

        return response()->json(['user_id' => $user_id]);
    }

    public function getFrequencies(Request $request)
    {
        $data_frequency_id = $request->input('data_frequency_id');

        if ($data_frequency_id) {
            $frequencies = RitFeature::where('data_frequency_id', $data_frequency_id)->get();
            return response()->json($frequencies);
        }

        return response()->json([]); // Return an empty array if no country is selected
    }

    /**
     * Display a listing of the resource.
     */
    public function dataUpload()
    {

        $departments = RitHelper::getActiveDepartments();

        $rit_frequencies = RitHelper::getActiveFrequencies();

        $rit_features = RitHelper::getActiveRitFeatures();
        
        return view('rit_submissions.data_upload', compact('departments','rit_frequencies','rit_features'));
    }

    public function upload(Request $request)
    {
       // Validate input
        /*$validated_data = $request->validate([
            'data_frequency_id' => 'required',  
            'filename'          => 'required|mimes:csv,zip|max:409600', // 400MB
            'rit_id'            => 'required',  
            'reportingDate'     => 'required',  
            'preparedBy'        => 'required',  
            'phone'             => 'required',  
        ]);*/

        // Validate form data
        $validated_data = $request->validate([
            'data_frequency_id' => 'required',
            'rit_id'            => 'required',
            'reportingDate'     => 'required',
            //'cutOffDate'        => 'nullable|date',
            'preparedBy'        => 'required',
            'phone'             => 'required',
            'filename'          => 'required|file|mimes:csv,zip|max:409600', // Example file validation
        ]);

        //dd($validated_data);
        // Handle file upload
        if ($request->hasFile('filename')) 
        {
            // Needed variables
            //Getting User’s IP Address
            $ip_address   = $request->ip(); //  $ip_address = $request->ip(); or request()->ip();
            //Retrieving the User-Agent
            $user_agent   = $request->header('User-Agent'); // $user_agent = $request->header('User-Agent');

            $user           = Auth::user(); // Get the authenticated user
            $user_id        = Auth::user()->user_id;
            $fi_id          = Auth::user()->fi_id;
            $bank_branch_id = Auth::user()->bank_branch_id;
            $user_name      = Auth::user()->user_name;
            $status_id      = Auth::user()->status_id;

            $reporting_date_string = Carbon::parse($validated_data['reportingDate'])->format('Ymd');


            // Get the original filename
            $originalName       = $request->file('filename')->getClientOriginalName();
            $file_original_name = $request->file('filename')->getClientOriginalName();

            $file_reporting_date   = substr($file_original_name, -12, 8);

            $rit_detail   = RitFeature::where('rit_id', $validated_data['rit_id'])->first();

            $rit_name     = $rit_detail->rit_name;
            $cut_off_days = $rit_detail->cut_off_days;

            $cut_off_date = date('Y-m-d', strtotime($reporting_date_string . "+" . $cut_off_days . " days"));

            $upload_date = date('Y-m-d');

            // T_PS_D_ASLI_BALANCES.77.770101.20250410.csv
            $predefined_rit_name = $rit_name.".".$fi_id.".".$bank_branch_id.".".$reporting_date_string.".csv";
           
            // T_PS_D_ASLI_BALANCES.77.770101.20250410

            //T_PS_D_ASLI_BALANCES.107.1070002.20250410.csv

            if( $file_original_name != $predefined_rit_name )
            {                
                if( $file_reporting_date != $reporting_date_string )
                {
                    echo "Mismatch between reporting date and file name date.";
                }
                else
                {                    
                    echo "Error in file name convention!";
                }
            }
            else
            {
                if ($upload_date >= $cut_off_date) 
                {
                    echo "CutOff Date is Over!";
                }
                else
                {
                    date_default_timezone_set('Asia/Dhaka');
                    // Store the file in the 'uploads' directory
                    $path = $request->file('filename')->storeAs('/', $originalName, 'edw');
                    //$path = $file->storeAs('uploads', $originalName, 'public');

                    // Save to database
                    $rit_submission = new RitSubmission;
                    $rit_submission->data_frequency_id = $validated_data['data_frequency_id'];
                    $rit_submission->rit_id            = $validated_data['rit_id'];
                    $rit_submission->fi_id             = $fi_id;
                    $rit_submission->bank_branch_id    = $bank_branch_id;
                    $rit_submission->user_id           = $user_id;
                    $rit_submission->file_name         = $originalName;
                    //$rit_submission->base_date       = $validated_data['reportingDate'];
                    $rit_submission->base_date         = Carbon::parse($validated_data['reportingDate'])->format('Y-m-d');

                    $rit_submission->prepared_by       = $validated_data['preparedBy'];
                    $rit_submission->phone_no          = $validated_data['phone'];
                    $rit_submission->upload_time       = Carbon::now();
                    $rit_submission->status_id         = $status_id;
                    $rit_submission->ip_address        = $ip_address;
                    $rit_submission->user_agent        = $user_agent;
                    $rit_submission->save();

                    //dd($user);
                    
                    //dd($validated_data);

                    //return back()->with('success', 'File uploaded successfully!')->with('filename', $originalName);
                    return back()->with('success', 'File uploaded successfully!');

                }
            }

        }        
        //return back()->with('error', 'No file has been selected!');  
        return back()->withErrors(['filename' => 'File upload failed.']);      
    }


}
