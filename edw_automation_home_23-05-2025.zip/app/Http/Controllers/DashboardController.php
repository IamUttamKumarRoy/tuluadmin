<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

// Library import
use Illuminate\Support\Facades\Session;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password; 

class DashboardController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function bankBranchEndDashboard()
    {       
        $var1 = '';
        $var2 = '';
        $var3 = '';

        $user           = Auth::user(); // Get the authenticated user
		return view('dashboard.index', compact('var1','var2','var3'));

       /* echo "<pre>";
        print_r($user->role_id);
        print_r($user);
        echo "</pre>";*/
	/*
       if ( $user->role_id == 103 ) {
           return view('dashboard.bank_end_user', compact('var1','var2','var3')); 
       } else {
        return view('dashboard.index', compact('var1','var2','var3'));
       }
	   */
    
        /*if (auth()->user()->hasRole('admin')) {
            return view('dashboard.index');
        } else {
            return view('dashboard.index');
        }*/
    }
}
