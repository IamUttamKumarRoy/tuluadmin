<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class FileUploadController extends Controller
{
    public function showForm()
    {
        return view('upload');
    }

    public function uploadFile(Request $request)
    {
        $request_data = $request->validate([
            'file' => 'required|image|mimes:jpeg,png,jpg,gif,pdf,csv,xls|max:2048',
        ]);

        dd($request_data);

        $fileName = time().'.'.$request->image->extension();
        $request->file->move(public_path('uploads'), $fileName);

        return back()->with('success', 'File uploaded successfully!')->with('file', $fileName);
    }
}