<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;


// Custom import
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

// Model import 
use App\Models\BankFi;
use App\Models\BankFiClass;
use App\Models\BankBranch;
use App\Models\RitFeature;
use App\Models\User;
use App\Models\DataFrequency;
use App\Models\RitSubmission;


use App\Helpers\RitHelper;

use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Session; // Import the Session class

class ReportController extends Controller
{
    public function uploadStatus(Request $request)
    {
        $validated_data     = array();
        $upload_status_data = array();

        $bankFiArray        = [];
        $bankBranchArray    = [];

        if ($request->isMethod('post')) 
        {
            // Handle form submission logic here
            //1. Validate the input
            $validated_data = $request->validate([
                'rit_id'           => 'required',
                //'bank_fi_id'       => 'required',
                'base_date_from'   => 'required',
                'base_date_to'     => 'required',
                'upload_date_from' => 'required',
                'upload_date_to'   => 'required'  
            ]);

            //dd($validated_data);
            $rit_id           = $request->input('rit_id');
            $bank_fi_id       = $request->input('bank_fi_id');            
            $upload_date_from = $request->input('upload_date_from');
            $upload_date_to   = $request->input('upload_date_to');

            $base_date_from   = $request->input('base_date_from');
            $base_date_to     = $request->input('base_date_to');

            $carbonDate_from  = \Carbon\Carbon::parse($base_date_from);
            $base_date_from = $carbonDate_from->format('Y-m-d');

            $carbonDate_to    = \Carbon\Carbon::parse($base_date_to);
            $base_date_to     = $carbonDate_to->format('Y-m-d');       
            
            $carbonDate_from  = \Carbon\Carbon::parse($upload_date_from);
            $upload_date_from = $carbonDate_from->format('Y-m-d');

            $carbonDate_to    = \Carbon\Carbon::parse($upload_date_to);
            $upload_date_to   = $carbonDate_to->format('Y-m-d');         

            if( !empty($bank_fi_id) ) {
                
                $upload_status_data = RitSubmission::where('rit_id', $rit_id)
                    ->whereBetween('base_date', [$base_date_from, $base_date_to])
                    ->whereBetween('upload_time', [$upload_date_from, $upload_date_to])
                    ->where('fi_id', $bank_fi_id) // Filtering by user role
                    ->get(); 
            } else {
                $upload_status_data = RitSubmission::where('rit_id', $rit_id)
                    ->whereBetween('base_date', [$base_date_from, $base_date_to])
                    ->whereBetween('upload_time', [$upload_date_from, $upload_date_to])                    
                    ->get();
            }


            $bankFiArray = RitHelper::getBankFiAsArray();
            $bankBranchArray = RitHelper::getBankBranchAsArray();

        }  
        // Fetch active rits
        $active_rits     = RitHelper::getActiveRitFeatures();
        $active_bank_fis = RitHelper::getActiveBankFi();

        //dd($active_bank_fis);

        //dd($bankBranchArray);                    
       
        return view('reports.upload_status', compact('bankFiArray','bankBranchArray','active_rits','active_bank_fis','validated_data','upload_status_data'));
    }

    public function uploadStatusByRit(Request $request)
    {
        $validated_data     = array();
        $upload_status_data = array();
        if ($request->isMethod('post')) 
        {
            // Handle form submission logic here
            //1. Validate the input
            $validated_data = $request->validate([
                'rit_id'           => 'required',
                'bank_fi_id'       => 'required',
                'upload_date_from' => 'required',
                'upload_date_to'   => 'required'  
            ]);

            $rit_id           = $request->input('rit_id');
            $bank_fi_id       = $request->input('bank_fi_id');            
            $upload_date_from = $request->input('upload_date_from');
            $upload_date_to   = $request->input('upload_date_to');

            $carbonDate_from  = \Carbon\Carbon::parse($upload_date_from);
            $upload_date_from = $carbonDate_from->format('Y-m-d');

            $carbonDate_to    = \Carbon\Carbon::parse($upload_date_to);
            $upload_date_to   = $carbonDate_to->format('Y-m-d');            

            $upload_status_data = RitSubmission::where('rit_id', $rit_id)
             ->whereBetween('upload_time', [$upload_date_from, $upload_date_to])
             ->where('fi_id', $bank_fi_id) // Filtering by user role
             ->get(); 

             //dd($upload_status_data);

            // 1. Get the data from the database using the query from the previous answer
            //$ritname   = $request->input('rit_id'); // Get parameters from request
            /*$bdate     = $request->input('base_date_from');
            $updatefrm = $request->input('upload_date_from');
            $updateto  = $request->input('upload_date_to');

            $query = DB::table('rit_submissions') // Replace 'your_table_name'
                ->distinct('bank_branch_id')
                ->select([
                    'FI_ID',
                    'bank_branch_id',
                    'FILE_NAME',
                    'BASE_DATE',
                    DB::raw('max(DATE(UPLOAD_TIME)) as Date'),
                    
                ])
                ->groupBy('FI_ID', 'bank_branch_id', 'FILE_NAME', 'BASE_DATE')
                ->where('RIT_ID', $rit_id)
                ->where('BASE_DATE', $bdate)
                ->where('UPLOAD_TIME', '>=', $updatefrm)
                ->where('UPLOAD_TIME', '<=', $updateto)
                ->get();

            $reportData = $query->collect(); // Get the results as a collection*/

            //dd($reportData);

            // 1. Validate the input
            /*$validator = Validator::make($request->all(), [
                'name' => 'required|string|max:255',
                'email' => 'required|email|max:255',
                'message' => 'required|string',
            ]);

            if ($validator->fails()) {
                return redirect()->route('my-form')
                            ->withErrors($validator)
                            ->withInput(); // Keep the user's input
            }*/

            // 2. Process the data (e.g., save to database, send email)
            // Example: Saving to a database (assuming you have a model named 'MyData')
            /*
            $data = new MyData();
            $data->name = $request->input('name');
            $data->email = $request->input('email');
            $data->message = $request->input('message');
            $data->save();
            */

            // 3. Optionally, you can send a success message
             //Session::flash('success', 'Your message has been sent successfully!');

            // 4. Redirect to a success page or back to the form
            //return redirect()->route('report.upload-status')->with('success', 'Form submitted successfully!'); 

        }  
        // Fetch active rits
        $active_rits     = RitHelper::getActiveRitFeatures();
        $active_bank_fis = RitHelper::getActiveBankFi();

        //dd($active_bank_fis);

        $bankFiArray = RitHelper::getBankFiAsArray();
        $bankBranchArray = RitHelper::getBankBranchAsArray();

        //dd($bankBranchArray);                    
       
        return view('reports.upload_status_by_rit', compact('bankFiArray','bankBranchArray','active_rits','active_bank_fis','validated_data','upload_status_data'));
    }

    public function nonReportingBranch(Request $request)
    {
        $validated_data     = array();
        $upload_status_data = array();
        $bank_branch_list   = [];
        $bankFiArray        = [];
        $bankBranchArray    = [];
        $branch_based_user  = [];

        if ($request->isMethod('post')) 
        {
            // Handle form submission logic here
            //1. Validate the input
            $validated_data = $request->validate([
                'rit_id'           => 'required',
                'bank_fi_id'       => 'required', 
                'base_date_from'   => 'required',
                'base_date_to'     => 'required',
            ]);

            $rit_id           = $request->input('rit_id');
            $bank_fi_id       = $request->input('bank_fi_id');            
            $base_date_from   = $request->input('base_date_from');
            $base_date_to     = $request->input('base_date_to');

            $carbonDate_from  = \Carbon\Carbon::parse($base_date_from);
            $base_date_from   = $carbonDate_from->format('Y-m-d');

            $carbonDate_to    = \Carbon\Carbon::parse($base_date_to);
            $base_date_to     = $carbonDate_to->format('Y-m-d');            

            $upload_status_data = RitSubmission::where('rit_id', $rit_id)
             ->whereBetween('base_date', [$base_date_from, $base_date_to])
             ->where('fi_id', $bank_fi_id) // Filtering by user role
             ->get();    

            // Get all branch of the given bank
            $bank_branch_data = BankBranch::where('fi_id', $bank_fi_id)->get();
            
            $reported_branch  = [];
            $bank_branch_list = [];
            $all_branch_ids   = [];
            //if( !empty($upload_status_data)) 
            if ($upload_status_data->isNotEmpty())
            {
                foreach( $upload_status_data as $upload_status )
                {
                    $reported_branch[$upload_status->bank_branch_id] = $upload_status->bank_branch_id;
                    //echo $upload_status->bank_branch_id."<br/>";
                }
            }
            
            //echo "<hr/>";
            //if( !empty($bank_branch_data)) 
            if ($bank_branch_data->isNotEmpty())
            {
                foreach( $bank_branch_data as $bank_branch )
                {
                    $all_branch_ids[$bank_branch->fi_branch_id] = $bank_branch->fi_branch_id;
                    // if data submitted then not needed
                    if( empty($reported_branch[$bank_branch->fi_branch_id]) ) {
                        $bank_branch_list[$bank_branch->fi_branch_id] = $bank_branch;
                        //echo $bank_branch->fi_branch_id."<br/>";
                    }                    
                }
            }

            // Get all branch of the given bank
            

            //DB::enableQueryLog(); // Start logging queries

            // Run your Eloquent query
            $user_data = User::whereIn('bank_branch_id', $all_branch_ids)->get();
            $branch_based_user = [];            
            if ($user_data->isNotEmpty())
            {
                foreach ($user_data as $key => $user) 
                {
                    $branch_based_user[$user->bank_branch_id] = $user->toArray();
                }
            }

            // Get the last executed query
            //dd(DB::getQueryLog());

            //echo "<pre>";
            //print_r(DB::getQueryLog()); 

            //echo "<hr/>";
            //dd($branch_based_user);
            //dd($user_data);

            $bankFiArray     = RitHelper::getBankFiAsArray();
            $bankBranchArray = RitHelper::getBankBranchAsArray();

        }  
        // Fetch active rits
        $active_rits     = RitHelper::getActiveRitFeatures();
        $active_bank_fis = RitHelper::getActiveBankFi();

        //dd($active_bank_fis);
        //dd($bankBranchArray);                    
       
        return view('reports.non_reporting_branch', compact( 'bankFiArray','bankBranchArray','active_rits','active_bank_fis',
        'validated_data','bank_branch_list','branch_based_user'));
    }
    
    public function nonReportingBank(Request $request)
    {
        $validated_data     = array();
        $upload_status_data = array();
        $bank_branch_list   = [];
        $bankFiArray        = [];
        $bankBranchArray    = [];
        $branch_based_user  = [];
        $bank_list          = [];

        if ($request->isMethod('post')) 
        {
            // Handle form submission logic here
            //1. Validate the input
            $validated_data = $request->validate([
                'rit_id'          => 'required',
                'financial_types' => 'required', 
                'base_date'       => 'required',
            ]);

            

            $rit_id           = $request->input('rit_id');
            $financial_types  = $request->input('financial_types');            
            $base_date        = $request->input('base_date');

            $carbonDate_bd    = \Carbon\Carbon::parse($base_date);
            $base_date        = $carbonDate_bd->format('Y-m-d');

            $fi_class_id      = [];

            if( !empty($financial_types) )
            {
                foreach ($financial_types as $key => $financial_type ) 
                {
                    if( $financial_type =="bank" ) {
                        $bank_class = [1001,1002,1003,1004,1005];
                        $fi_class_id = array_merge($fi_class_id,$bank_class);
                    } 
                    if( $financial_type =="nbfi" ) {
                        $bank_class = [1009,10010];
                        $fi_class_id = array_merge($fi_class_id,$bank_class);
                    }
                    if( $financial_type =="mfs" ) {
                        $bank_class = [8000];
                        $fi_class_id = array_merge($fi_class_id,$bank_class);
                    }
                    if( $financial_type =="pso" ) {
                        $bank_class = [9000];
                        $fi_class_id = array_merge($fi_class_id,$bank_class);
                    }
                }
            }
            

            

      
            $upload_status_data = RitSubmission::where('rit_id', $rit_id)
             ->where('base_date', $base_date) // Filtering by user role
             ->get();    

            // Get all branch of the given bank
            //$bank_branch_data = BankBranch::where('fi_id', $bank_fi_id)->get();
            $bank_data = BankFi::where('status_id', 1)             
             ->whereIn('bank_fi_class_id', $fi_class_id) // Filtering by user role
             ->get(); 

            
            
            $reported_bank  = [];
            $bank_list      = [];
            $all_bank_ids   = [];
            //if( !empty($upload_status_data)) 
            if ($upload_status_data->isNotEmpty())
            {
                foreach( $upload_status_data as $upload_status )
                {
                    $reported_bank[$upload_status->fi_id] = $upload_status->fi_id;                    
                }
            }
            
            //echo "<hr/>";
            //if( !empty($bank_branch_data)) 
            if ($bank_data->isNotEmpty())
            {
                foreach( $bank_data as $bank )
                {
                    $all_bank_ids[$bank->fi_id] = $bank->fi_id;
                    // if data submitted then not needed
                    if( empty($reported_bank[$bank->fi_id]) ) {
                        $bank_list[$bank->fi_id] = $bank;
                        //echo $bank_branch->fi_branch_id."<br/>";
                    }                    
                }
            }
           //echo "<pre>";
           //print_r($bank_list); 
           //dd($upload_status_data);
            

            //DB::enableQueryLog(); // Start logging queries

            // Run your Eloquent query
            //$user_data = User::whereIn('bank_branch_id', $all_branch_ids)->get();
            $user_data = [];
            $branch_based_user = [];            
            /*if ($user_data->isNotEmpty())
            {
                foreach ($user_data as $key => $user) 
                {
                    $branch_based_user[$user->bank_branch_id] = $user->toArray();
                }
            }
            */
            // Get the last executed query
            //dd(DB::getQueryLog());

            //echo "<pre>";
            //print_r(DB::getQueryLog()); 

            //echo "<hr/>";
            //dd($branch_based_user);
            //dd($user_data);

            $bankFiArray     = RitHelper::getBankFiAsArray();
            //$bankBranchArray = RitHelper::getBankBranchAsArray();

        }  
        // Fetch active rits
        $active_rits     = RitHelper::getActiveRitFeatures();
        $active_bank_fis = RitHelper::getActiveBankFi();

       $financialEntities = [
            'bank' => 'Bank',
            'nbfi' => 'NBFI',
            'mfs' => 'MFS',
            'pso' => 'PSO'
        ];                
       
        return view('reports.non_reporting_bank', compact( 'bankFiArray','bankBranchArray','active_rits','active_bank_fis',
        'validated_data','bank_list','branch_based_user','financialEntities'));
    }    
}
