<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

// Custom import
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

// Model import 
use App\Models\BankFi;
use App\Models\BankFiClass;
use App\Models\BankBranch;
use App\Models\RitFeature;
use App\Models\User;
use App\Models\DataFrequency;
use App\Models\RitSubmission;

use App\Helpers\RitHelper;

use Illuminate\Support\Facades\Validator;
use League\Csv\Reader;


class MigrationController extends Controller
{
    
    // Display a listing of the resource
    public function migrateDfiToBankFi()
    {
        //$fis = Fi::all();
         
        $record_data = DB::select("SELECT DISTINCT FI_ID,FI_NM,FI_ALIAS,GEO_AREA_ID FROM d_fi WHERE FI_ID NOT IN(117,133,106,0) AND FI_ID!=117 order by FI_ID ASC");
        
        // Clears existing data before seeding
        //DB::table('bank_fis')->truncate(); 
        // Variable declaration
        $record_arr = array();
        $inc = 0;
        if( !empty($record_data) )
        {
            foreach ($record_data as $key=> $row) 
            {
                echo $row->FI_ID;
                echo "==>";
                echo $row->FI_NM;
                echo "<br/>";

                $record_arr[$inc]['fi_id']            = $row->FI_ID;
                $record_arr[$inc]['fi_nm']            = $row->FI_NM;
                $record_arr[$inc]['fi_alias']         = $row->FI_ALIAS;
                $record_arr[$inc]['geo_area_id']      = $row->GEO_AREA_ID;
                $record_arr[$inc]['bank_fi_class_id'] = 9999;
                                        
                BankFi::insert($record_arr[$inc]);
            
                $inc++;
            }            
        }


        dd($record_arr);
         
        //return view('fis.index', compact('fis'));
    }

    public function migrateBankFiClass(Request $request)
    {
        $record_data = DB::select("SELECT DISTINCT FI_CLASS_ID,FI_INST_TYPE,FI_CATEGORY,FI_CLUSTER FROM d_fi_class ORDER BY FI_CLASS_ID ASC");

        echo "Started:<br/>";

        $record_arr   = array();
        $ip_address   = $request->ip(); //  $ip_address = $request->ip(); or request()->ip();
        $user_agent   = $request->header('User-Agent'); // $user_agent = $request->header('User-Agent');

        if( !empty($record_data) )
        {
            $inc = 0; 
            foreach ($record_data as $key=> $row) 
            {
                $record_arr[$inc]['fi_class_id']   = $row->FI_CLASS_ID;
                $record_arr[$inc]['fi_inst_type']  = $row->FI_INST_TYPE;
                $record_arr[$inc]['fi_category']   = $row->FI_CATEGORY;
                $record_arr[$inc]['fi_cluster']    = $row->FI_CLUSTER;                 
                
                BankFiClass::insert($record_arr[$inc]);
                         
                $inc++;
            }            
        }
        echo "Finished:<br/>";
        //dd($record_arr);
        dd($user_agent);

        return view('not_needed_view');
    }

    public function updateBankFiClassIDs(Request $request)
    {
        $record_data = DB::select("SELECT DISTINCT FI_ID,FI_CLASS_ID FROM tbl_bank_branch WHERE FI_ID NOT IN (0) AND FI_CLASS_ID NOT IN (0,1,9999) ORDER BY FI_ID");

        echo "Started:<br/>";

        $record_arr   = array();
        $ip_address   = $request->ip(); //  $ip_address = $request->ip(); or request()->ip();
        $user_agent   = $request->header('User-Agent'); // $user_agent = $request->header('User-Agent');

        if( !empty($record_data) )
        {
            $inc = 0; 
            foreach ($record_data as $key=> $row) 
            {
                $record_arr[$inc]['FI_ID']   = $row->FI_ID;
                $record_arr[$inc]['FI_CLASS_ID']  = $row->FI_CLASS_ID;                

                if ( !empty($row->FI_ID) && !empty($row->FI_CLASS_ID) )
                {
                    $bank_fi = BankFi::where('fi_id', $row->FI_ID)->first();
                    if ($bank_fi) 
                    {
                        $bank_fi->bank_fi_class_id = $row->FI_CLASS_ID;
                        $bank_fi->save();
                    }                 
                }                   

                $inc++;
            }            
        }
        echo "Finished:<br/>";
        //dd($record_arr);
        dd($record_arr);

        return view('not_needed_view');
    }

    public function migrateBankBranch(Request $request)
    {
        //$record_data = DB::select("SELECT * FROM tbl_bank_branch WHERE FI_ID IN ( SELECT FI_ID from d_fi)");
        //$record_data = DB::select("SELECT * FROM tbl_bank_branch WHERE FI_ID IN ( SELECT FI_ID from d_fi) AND FI_ID NOT IN (0) AND FI_BRANCH_ID NOT IN(0,1) ORDER BY  FI_ID ASC");
        $record_data = DB::select("SELECT * FROM tbl_bank_branch WHERE FI_ID IN ( SELECT FI_ID from d_fi) AND FI_ID NOT IN (0) AND FI_BRANCH_ID NOT IN(0,1) 
                AND FI_BRANCH_ID NOT IN( SELECT FI_BRANCH_ID FROM (
                SELECT FI_BRANCH_ID, count(*) FROM tbl_bank_branch  
                WHERE FI_ID NOT IN (0) AND FI_BRANCH_ID NOT IN(0,1)  GROUP BY FI_BRANCH_ID HAVING count(*)>1 
                ) RR)
                ORDER BY FI_ID ASC");

        echo "Started:<br/>";

        $record_arr   = array();
        $ip_address   = $request->ip();                 //  $ip_address = $request->ip(); or request()->ip();
        $user_agent   = $request->header('User-Agent'); // $user_agent = $request->header('User-Agent');

        if( !empty($record_data) )
        {
            $inc = 0; 
            foreach ($record_data as $key=> $row) 
            {
                $record_arr[$inc]['fi_branch_id']     = $row->FI_BRANCH_ID;
                $record_arr[$inc]['fi_id']            = $row->FI_ID;
                $record_arr[$inc]['branch_name']      = $row->BRANCH_NM;
                $record_arr[$inc]['division']         = $row->DIVISION;
                $record_arr[$inc]['district']         = $row->DISTRICT;
                $record_arr[$inc]['thana']            = $row->THANA;  
                $record_arr[$inc]['status_id']        = 1; 
                
                //BankBranch::insert($record_arr[$inc]);
                /*
                try {
                    BankBranch::insert($record_arr[$inc]);
                } 
                catch (QueryException $e) 
                {
                    echo "Database Error: " . $e->getMessage();
                    echo "<br/>" . $row->FI_BRANCH_ID;
                    Log::error("Database error while saving user: " . $e->getMessage());
                }*/
                
                $inc++;
            }            
        }

        if( !empty($record_arr) )
        {
            $temp_arr = array();
            //$inc = 0;
            foreach ($record_arr as $key => $row) 
            {
                $temp_arr['fi_branch_id']     = $row['fi_branch_id'];
                $temp_arr['fi_id']            = $row['fi_id'];
                $temp_arr['branch_name']      = trim($row['branch_name']);
                            
                $temp_arr['division']         = trim($row['division']);
                $temp_arr['district']         = trim($row['district']);
                $temp_arr['thana']            = trim($row['thana']);  
                //$temp_arr['status_id']        = $row['status_id'];
                 

                //Log::channel('daily_custom')->info(json_encode($temp_arr));

                try {                    
                    $bank_branch    = new BankBranch();
                    $bank_branch->fi_branch_id  = trim($row['fi_branch_id']);
                    $bank_branch->fi_id         = trim($row['fi_id']);
                    $bank_branch->branch_name   = trim($row['branch_name']);
                    $bank_branch->division      = trim($row['division']);
                    $bank_branch->district      = trim($row['district']);
                    $bank_branch->thana         = trim($row['thana']);
                    $bank_branch->status_id     = 1;
                    $bank_branch->save();
                } 
                catch (QueryException $e) 
                {
                    echo "Database Error: " . $e->getMessage();
                    Log::channel('daily_custom')->info(json_encode($temp_arr));
                }

                //$inc++;
            }
        }



        //dispatch(new PrepareBankBranchesImportBatch($record_arr));

        echo "Finished:<br/>";

        echo($inc);
        //dd($user_agent);


        return view('not_needed_view');
    }

    public function migrateRitFeature(Request $request)
    {
        $record_info = DB::select("SELECT * FROM tbl_rit_features order by RIT_ID ASC");

        echo "Started:<br/>";

        $insert_record  = array();
        $ip_address   = $request->ip(); //  $ip_address = $request->ip(); or request()->ip();
        $user_agent   = $request->header('User-Agent'); // $user_agent = $request->header('User-Agent');
        //dd($record_info);
        if( !empty($record_info) )
        {
            $inc = 0; 
            foreach ($record_info as $key=> $row) 
            {
                $insert_record[$inc]['rit_id']       = $row->rit_id;
                $insert_record[$inc]['rit_name']     = $row->rit_name;
                $insert_record[$inc]['rit_freq']     = $row->rit_freq;
                $insert_record[$inc]['rit_version']  = $row->rit_version;                 
                $insert_record[$inc]['no_of_col']    = $row->no_of_col;                 
                $insert_record[$inc]['no_of_row']    = $row->no_of_row;                 
                $insert_record[$inc]['cut_off_days'] = $row->cut_off_days;                 
                $insert_record[$inc]['dept']         = $row->dept;                 
                //$insert_record[$inc]['freq_full']    = $row->freq_full;                 
                $insert_record[$inc]['status']       = $row->status;                 
                $insert_record[$inc]['validate']     = $row->validate;                 
                $insert_record[$inc]['status_id']    = 1;                 
                
                RitFeature::insert($insert_record[$inc]);
                         
                $inc++;
            }            
        }
        echo "Finished:<br/>";  
        //dd($user_record);
        //dd($ip_address);

        return view('not_needed_view');
    }

    public function migrateUser(Request $request)
    {

        $user_info = DB::select("SELECT * FROM tbl_user WHERE user_id='uttam'");
        $user_info = DB::select("SELECT * FROM tbl_user  WHERE FI_ID IN (SELECT FI_ID FROM bank_fis) 
                            AND FI_BR_ID IN (SELECT fi_branch_id FROM bank_branches)");

        echo "Started:<br/>";

        $user_record  = array();
        $ip_address   = $request->ip(); //  $ip_address = $request->ip(); or request()->ip();
        $user_agent   = $request->header('User-Agent'); // $user_agent = $request->header('User-Agent');

        if( !empty($user_info) )
        {
            $inc = 0; 
            foreach ($user_info as $key=> $row) 
            {
                $user_record[$inc]['report_type_id']   = !empty(trim($row->REPORT_TYPE_ID)) ? trim($row->REPORT_TYPE_ID) : '';
                $user_record[$inc]['user_id']          = $row->USER_ID;
                $user_record[$inc]['password']         = $row->PASSWORD;
                $user_record[$inc]['fi_id']            = $row->FI_ID;
                $user_record[$inc]['bank_branch_id']   = $row->FI_BR_ID;
                $user_record[$inc]['user_name']        = $row->USER_NAME;
                $user_record[$inc]['role']             = $row->ROLE;
                $user_record[$inc]['role_id']          = 1;
                $user_record[$inc]['status']           = $row->STATUS;
                $user_record[$inc]['status_id']        = 1;
                $user_record[$inc]['online']           = $row->ONLINE;
                $user_record[$inc]['block']            = $row->BLOCK;
                $user_record[$inc]['email']            = $row->EMAIL;
                $user_record[$inc]['approve_time']     = $row->APPROVE_TIME;
                $user_record[$inc]['approved_by']      = $row->APPROVED_BY;
                $user_record[$inc]['designation']      = $row->DESIGNATION;
                $user_record[$inc]['dept_sec_desk']    = $row->DEPT_SEC_DESK;
                $user_record[$inc]['cell_no']          = $row->CELL_NO;
                $user_record[$inc]['phone_no']         = $row->PHONE_NO;
                $user_record[$inc]['creation_time']    = $row->CREATION_TIME;
                $user_record[$inc]['last_login']       = $row->LAST_LOGIN;
                $user_record[$inc]['failure_attempts'] = !empty($row->FAILURE_ATTEMPTS) ? $row->FAILURE_ATTEMPTS: 0;
                $user_record[$inc]['ip_address']       = $ip_address;
                $user_record[$inc]['user_agent']       = $user_agent;
                //$user_record[$inc]['created_at']       = $row->CREATION_TIME;
                //$user_record[$inc]['created_by']       = '';
                //$user_record[$inc]['updated_at']       = $row->LAST_PASS_UPDATED;
                //$user_record[$inc]['updated_by']       = $row->PASS_UPDATED_BY;
                $user_record[$inc]['status_id']        = 1; 
                
               // User::insert($user_record[$inc]);
                
                $inc++;
            }            
        }

        if( !empty($user_record) )
        {
            $insert_arr = array(); 
            foreach ($user_record as $key => $row ) 
            {                
                $insert_arr['report_type_id']   = trim($row['report_type_id']);
                $insert_arr['user_id']          = trim($row['user_id']);
                $insert_arr['password']         = trim($row['password']);
                $insert_arr['fi_id']            = trim($row['fi_id']);
                $insert_arr['bank_branch_id']   = trim($row['bank_branch_id']);
                $insert_arr['user_name']        = trim($row['user_name']);
                $insert_arr['role']             = trim($row['role']);
                $insert_arr['role_id']          = trim($row['role_id']);
                $insert_arr['status']           = trim($row['status']);
                $insert_arr['status_id']        = trim($row['status_id']);
                $insert_arr['online']           = trim($row['online']);
                $insert_arr['block']            = trim($row['block']);
                $insert_arr['email']            = trim($row['email']);
                $insert_arr['approve_time']     = trim($row['approve_time']);
                $insert_arr['approved_by']      = trim($row['approved_by']);
                $insert_arr['designation']      = trim($row['designation']);
                $insert_arr['dept_sec_desk']    = trim($row['dept_sec_desk']);
                $insert_arr['cell_no']          = trim($row['cell_no']);
                $insert_arr['phone_no']         = trim($row['phone_no']);
                $insert_arr['creation_time']    = trim($row['creation_time']);
                $insert_arr['last_login']       = trim($row['last_login']);
                $insert_arr['failure_attempts'] = trim($row['failure_attempts']);
                $insert_arr['ip_address']       = trim($row['ip_address']);
                $insert_arr['user_agent']       = trim($row['user_agent']);
                //$insert_arr['created_at']       = trim($row['created_at']);
                //$insert_arr['created_by']       = trim($row['created_by']);
                //$insert_arr['updated_at']       = trim($row['updated_at']);
                //$insert_arr['updated_by']       = trim($row['updated_by']);
                $insert_arr['status_id']        = trim($row['status_id']);

                //Log::channel('daily_error_log')->info(json_encode($insert_arr));

                try {                    
                    User::insert($insert_arr);
                } 
                catch (QueryException $e) 
                {
                    echo "Database Error: " . $e->getMessage();
                    Log::channel('test_log')->info(json_encode($insert_arr));
                }

            }
        }
        echo "Finished:<br/>";
        //dd($user_record);
        dd($insert_arr);

        return view('not_needed_view');
    }

    public function migrateDataFrequency(Request $request)
    {
        $user_info = DB::select("SELECT DISTINCT rit_freq,freq_full  FROM tbl_rit_features ");

        echo "Started:<br/>";

        $user_record    = array();
        $insert_record  = array();
        $ip_address   = $request->ip(); //  $ip_address = $request->ip(); or request()->ip();
        $user_agent   = $request->header('User-Agent'); // $user_agent = $request->header('User-Agent');

        if( !empty($user_info) )
        {
            $inc = 0; 
            foreach ($user_info as $key=> $row) 
            {
                /*$user_record[$inc]['rit_freq']   = $row->rit_freq;
                $user_record[$inc]['freq_full']  = $row->freq_full; 
                $user_record[$inc]['status_id']  = 1; */

                $insert_record['short_name']  = trim($row->rit_freq); 
                $insert_record['full_name']   = trim($row->freq_full); 
                $insert_record['description'] = trim($row->freq_full); 
                $insert_record['status_id']   = 1; 
                
                
               DataFrequency::insert($insert_record);
                
                $inc++;
            }            
        }

         
        echo "Finished:<br/>";
        //dd($user_record);
        dd($insert_record);

        return view('not_needed_view');
    }

    public function updateRitFeature(Request $request)
    {
        $record_data = DB::select("SELECT * FROM rit_features ORDER BY rit_id ASC");

        echo "Started:<br/>";

        $record_arr   = array();
        $ip_address   = $request->ip(); //  $ip_address = $request->ip(); or request()->ip();
        $user_agent   = $request->header('User-Agent'); // $user_agent = $request->header('User-Agent');

        if( !empty($record_data) )
        {
            $inc = 0; 
            foreach ($record_data as $key=> $row) 
            {
                $record_arr[$inc]['id']        = $row->id;
                $record_arr[$inc]['rit_name']  = $row->rit_name;                
                $record_arr[$inc]['rit_freq']  = $row->rit_freq;                

                if ( !empty($row->rit_freq) )
                {
                    $frequency = DataFrequency::where('short_name', $row->rit_freq)->first();
                    if ($frequency) 
                    {
                        $rit_feature = RitFeature::where('id', $row->id)->first();

                        $rit_feature->data_frequency_id = $frequency->id;
                        $rit_feature->save();
                    }                 
                }                   

                $inc++;
            }            
        }
        echo "Finished:<br/>";
        //dd($record_arr);
        dd($record_arr);

        return view('not_needed_view');
    }

    public function migrateRitSubmission(Request $request)
    {    
        $frequency_text = 'D';
        $data_frequency_id = RitHelper::findItemId("name", $frequency_text);

        echo "Data_frequency {$frequency_text}: ";
        echo "{$data_frequency_id}<br/>";

        $frequency_text = 'W';
        $data_frequency_id = RitHelper::findItemId("name", $frequency_text);

        echo "Data_frequency {$frequency_text}: ";
        echo "{$data_frequency_id}<br/>";        

        $frequency_text = 'M';
        $data_frequency_id = RitHelper::findItemId("name", $frequency_text);

        echo "Data_frequency {$frequency_text}: ";
        echo "{$data_frequency_id}<br/>";           

        //exit;
        //$table_records = DB::select("SELECT * FROM tbl_rit_sv  WHERE BASE_DATE='2024-10-31' AND RIT_NAME !='T_PS_M_FI_MONITOR_BR'");
        $table_records = DB::select("SELECT * FROM tbl_rit_sv  WHERE SL_NO BETWEEN 1916767 AND 1918349");

        echo "Started:<br/>"; 


        $user_record  = array();
        $ip_address   = $request->ip(); //  $ip_address = $request->ip(); or request()->ip();
        $user_agent   = $request->header('User-Agent'); // $user_agent = $request->header('User-Agent');

        if( !empty($table_records) )
        {
            $inc = 0; 
            foreach ($table_records as $key=> $row) 
            {
                $user_record[$inc]['rit_id']           = $row->RIT_ID;
                $user_record[$inc]['fi_id']            = $row->FI_ID;
                $user_record[$inc]['bank_branch_id']   = $row->FI_BR_ID;
                $user_record[$inc]['user_id']          = $row->USER_ID;
                $user_record[$inc]['data_frequency_id']= RitHelper::findItemId("name", $row->RIT_FREQ);
                $user_record[$inc]['file_name']        = $row->FILE_NAME;
                $user_record[$inc]['base_date']        = $row->BASE_DATE;                
                $user_record[$inc]['phone_no']         = $row->PHONE_NO;
                $user_record[$inc]['prepared_by']      = $row->PREPARED_BY;
                $user_record[$inc]['upload_time']      = $row->UPLOAD_TIME;
                $user_record[$inc]['ip_address']       = $row->IP;
                $user_record[$inc]['user_agent']       = '';
                $user_record[$inc]['status_id']        = 1; 
                
               // User::insert($user_record[$inc]);
                
                $inc++;
            }            
        }

        if( !empty($user_record) )
        {
            $insert_arr = array(); 
            $inc = 0;
            foreach ($user_record as $key => $row ) 
            {                
                $insert_arr[$inc]['rit_id']           = trim($row['rit_id']);
                $insert_arr[$inc]['fi_id']            = trim($row['fi_id']);
                $insert_arr[$inc]['bank_branch_id']   = trim($row['bank_branch_id']);
                $insert_arr[$inc]['user_id']          = trim($row['user_id']);
                $insert_arr[$inc]['data_frequency_id']= trim($row['data_frequency_id']);
                $insert_arr[$inc]['file_name']        = trim($row['file_name']);
                $insert_arr[$inc]['base_date']        = trim($row['base_date']);
                $insert_arr[$inc]['phone_no']         = trim($row['phone_no']);
                $insert_arr[$inc]['prepared_by']      = trim($row['prepared_by']);
                $insert_arr[$inc]['upload_time']      = trim($row['upload_time']);                
                $insert_arr[$inc]['ip_address']       = trim($row['ip_address']);
                $insert_arr[$inc]['user_agent']       = trim($row['user_agent']);
                $insert_arr[$inc]['status_id']        = trim($row['status_id']);

                Log::channel('daily_error_log')->info(json_encode($insert_arr[$inc]));

                
                $inc++;
            }
        }
        try {                    
            RitSubmission::insert($insert_arr);
        } 
        catch (QueryException $e) 
        {
            echo "Database Error: " . $e->getMessage();
            Log::channel('test_log')->info(json_encode($insert_arr));
        }

        echo "Finished:<br/>";
        //dd($user_record);
        dd($insert_arr);

        return view('not_needed_view');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function migrateBankFiClassForm()
    {
        $test_var = '';
       
        return view('migrations.import-branch', compact('test_var'));
    }
    public function migrateBankFiClassPost(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'csv_file' => 'required|mimes:csv,txt',
        ]);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }

        $file = $request->file('csv_file');

        try {
            $csv = Reader::createFromPath($file->getPathname(), 'r');
            $csv->setHeaderOffset(0); // Assuming the first row of your CSV contains headers

            $insertedCount = 0;
            $skippedCount = 0;

            DB::beginTransaction();

            foreach ($csv->getRecords() as $record) {
                $FI_ID       = $record['FI_ID'] ?? null;
                $FI_CLASS_ID  = $record['FI_CLASS_ID'] ?? null; 

                 echo $FI_ID."<==>".$FI_CLASS_ID."<br/>";

                if ( !empty($FI_ID) && !empty($FI_CLASS_ID) )
                {
                    $bank_fi = BankFi::where('fi_id', $FI_ID)->first();
                    if ($bank_fi) 
                    {
                        $bank_fi->bank_fi_class_id = $FI_CLASS_ID;
                        $bank_fi->save();
                    }                 
                }
            }

            DB::commit();

           // return redirect()->route('migrations.update-bank-class')->with('success', "Successfully imported {$insertedCount} records. {$skippedCount} records were skipped due to existing `fi_branch_id`.");

        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()->withErrors(['error' => 'Error processing CSV file: ' . $e->getMessage()])->withInput();
        }
    }     
}
