<?php 
// app/Services/MenuService.php
namespace App\Services;

class MenuService
{
    public function getMenuItems($role)
    {
        $menus = [
            'admin' => [
                ['name' => 'Dashboard', 'route' => 'admin.dashboard', 'icon' => 'fas fa-tachometer-alt'],
                ['name' => 'Users', 'route' => 'admin.users', 'icon' => 'fas fa-users'],
                ['name' => 'Settings', 'route' => 'admin.settings', 'icon' => 'fas fa-cog'],
                ['name' => 'Reports', 'route' => 'admin.reports', 'icon' => 'fas fa-chart-bar'],
            ],
            'manager' => [
                ['name' => 'Dashboard', 'route' => 'manager.dashboard', 'icon' => 'fas fa-tachometer-alt'],
                ['name' => 'Projects', 'route' => 'manager.projects', 'icon' => 'fas fa-project-diagram'],
                ['name' => 'Team', 'route' => 'manager.team', 'icon' => 'fas fa-users'],
            ],
            'user' => [
                ['name' => 'Dashboard', 'route' => 'user.dashboard', 'icon' => 'fas fa-tachometer-alt'],
                ['name' => 'Tasks', 'route' => 'user.tasks', 'icon' => 'fas fa-tasks'],
                ['name' => 'Profile', 'route' => 'user.profile', 'icon' => 'fas fa-user'],
            ],
        ];

        return $menus[$role] ?? $menus['user'];
    }
}