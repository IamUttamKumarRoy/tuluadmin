// app/Providers/ViewServiceProvider.php
namespace App\Providers;

use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;
use App\Services\MenuService;

class ViewServiceProvider extends ServiceProvider
{
    public function boot()
    {
        View::composer('layouts.app', function ($view) {
            if (auth()->check()) {
                $menuService = new MenuService();
                $menuItems = $menuService->getMenuItems(auth()->user()->role->name);
                $view->with('menuItems', $menuItems);
            }
        });
    }
}