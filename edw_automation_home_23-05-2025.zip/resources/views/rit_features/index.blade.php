@extends('layouts.adminlte_3') 

@section('content')
<div class="container-fluid">
    <div class="row">
        <h1>RIT Features</h1>
        <a href="{{ route('rit-features.create') }}" class="btn btn-primary mb-3">Create New RIT Feature</a>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>RIT ID</th>
                    <th>Name</th>
                    <th>Frequency</th>
                    <th>Version</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($ritFeatures as $ritFeature)
                    <tr>
                        <td>{{ $ritFeature->id }}</td>
                        <td>{{ $ritFeature->rit_id }}</td>
                        <td>{{ $ritFeature->rit_name }}</td>
                        <td>{{ $ritFeature->rit_freq }}</td>
                        <td>{{ $ritFeature->rit_version }}</td>
                        <td>
                            <a href="{{ route('rit-features.show', $ritFeature->id) }}" class="btn btn-info">View</a>
                            <a href="{{ route('rit-features.edit', $ritFeature->id) }}" class="btn btn-warning">Edit</a>
                            <form action="{{ route('rit-features.destroy', $ritFeature->id) }}" method="POST" style="display:inline;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
        {{ $ritFeatures->links() }}
    </div>
</div>
@endsection