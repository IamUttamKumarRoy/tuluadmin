<!-- resources/views/layouts/app.blade.php -->
<!DOCTYPE html>
<html>
<head>
    <!-- Head content -->
</head>
<body>
    <div class="wrapper">
        @auth
            <x-sidebar />
        @endauth
        
        <div class="content">
            @yield('content')
        </div>
    </div>
</body>
</html>