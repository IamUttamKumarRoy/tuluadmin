<!-- resources/views/roles/permissions.blade.php -->
@extends('layouts.adminlte_3') 

@section('content')
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h2>Manage Permissions for Role: {{ $role->name }}</h2>
                </div>

                <div class="card-body">
                    <form method="POST" action="{{ route('roles.update-permissions', $role->id) }}">
                        @csrf

                        @foreach($permissions as $group => $groupPermissions)
                        <div class="card mb-4">
                            <div class="card-header bg-light">
                                <h5 class="mb-0">
                                    {{ ucfirst($group) }} Permissions
                                </h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    @foreach($groupPermissions as $permission)
                                    <div class="col-md-3 mb-3">
                                        <div class="form-check">
                                            <input class="form-check-input" 
                                                   type="checkbox" 
                                                   name="permissions[]" 
                                                   value="{{ $permission->id }}"
                                                   id="permission_{{ $permission->id }}"
                                                   {{ $role->permissions->contains($permission->id) ? 'checked' : '' }}>
                                            <label class="form-check-label" for="permission_{{ $permission->id }}">
                                                {{ $permission->name }}
                                            </label>
                                            <small class="d-block text-muted">
                                                {{ $permission->route_uri }} ({{ $permission->http_method }})
                                            </small>
                                        </div>
                                    </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                        @endforeach

                        <div class="d-flex justify-content-between mt-4">
                            <a href="{{ route('roles.index') }}" class="btn btn-secondary">
                                Back to Roles
                            </a>
                            <button type="submit" class="btn btn-primary">
                                Update Permissions
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection