<!-- resources/views/components/sidebar.blade.php -->
<div class="sidebar">
    <div class="sidebar-header">
        <h3>Menu</h3>
    </div>
    <nav class="sidebar-nav">
        <ul class="nav flex-column">
            @isset($menuItems)
                @foreach($menuItems as $item)
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route($item['route']) }}">
                            <i class="{{ $item['icon'] }}"></i>
                            <span>{{ $item['name'] }}</span>
                        </a>
                    </li>
                @endforeach
            @endisset
        </ul>
    </nav>
</div>