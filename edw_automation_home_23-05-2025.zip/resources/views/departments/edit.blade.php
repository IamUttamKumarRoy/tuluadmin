@extends('layouts.app')

@section('content')
    <h1>Edit Department</h1>
    <form action="{{ route('departments.update', $department->id) }}" method="POST">
        @csrf
        @method('PUT')
        <div>
            <label for="name">Name:</label>
            <input type="text" name="name" id="name" value="{{ $department->name }}" required>
        </div>
        <div>
            <label for="description">Description:</label>
            <textarea name="description" id="description">{{ $department->description }}</textarea>
        </div>
        <div>
            <label for="section">Section:</label>
            <input type="text" name="section" id="section" value="{{ $department->section }}" required>
        </div>
        <div>
            <label for="status_id">Status ID:</label>
            <input type="number" name="status_id" id="status_id" value="{{ $department->status_id }}">
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
@endsection