<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    /** @use HasFactory<\Database\Factories\UserFactory> */
    //use HasFactory, Notifiable;
    use  Notifiable;


    protected $primaryKey = 'user_id'; // Set custom primary key

    public $incrementing = false;
    protected $keyType = 'string';

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    
    protected $fillable = [
        'report_type_id',
        'user_id',
        'password',
        'temp_password',
        'fi_id',
        'bank_branch_id',
        'user_name',
        'role',
        'role_id',
        'status',
        'status_id',
        'online',
        'block',
        'email',
        'approve_time',
        'approved_by',
        'designation',
        'dept_sec_desk',
        'cell_no',
        'phone_no',
        'creation_time',
        'failure_attempts',
        'ip_address',
        'user_agent',
        'created_by',
        'updated_by',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    public function getAuthIdentifierName()
    {
        return 'user_id';
    }

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    /*protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
        ];
    }*/
}
