<?php
  
namespace App\Http\Controllers;
       
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
      
class FileController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(): View
    {
        return view('fileUpload');
    }
        
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request): RedirectResponse
    {
        $request->validate([
            'file' => 'required|mimes:pdf,xlx,csv|max:409600',
        ]);
        
        $fileName = time().'.'.$request->file->extension();  
         
        $request->file->move(public_path('uploads'), $fileName);
       
        /*  
            Write Code Here for
            Store $fileName name in DATABASE from HERE 
        */
         
        return back()->with('success', 'File uploaded successfully!')
                     ->with('file', $fileName);
   
    }
	
	    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function uploadForm(): View
    {
        return view('upload_form');
    }
	
	/**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function uploadfile(Request $request): RedirectResponse
    {


       // Validate the file
		$validated_file = $request->validate([
			'file' => 'required|mimes:zip,csv|max:409600',
		]);

        

		// Get the original filename
		$originalName = $request->file('file')->getClientOriginalName();

		// Define a pattern (e.g., only alphanumeric and underscores)
		$pattern = '/^[a-zA-Z0-9_]+\.[a-zA-Z0-9]+$/';

		// Check if the filename matches the pattern
		/* if (!preg_match($pattern, $originalName)) {
			return back()->with('error', 'Invalid filename format.');
		} */

		// Store the file in the 'uploads' directory
		$path = $request->file('file')->storeAs('/', $originalName, 'edw');
		//$path = $file->storeAs('uploads', $originalName, 'public');

		return back()->with('success', 'File uploaded successfully!')->with('file', $originalName);
   
    }
}
