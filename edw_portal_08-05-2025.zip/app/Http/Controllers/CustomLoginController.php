<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;

use Illuminate\Support\Facades\Hash;

use App\Models\User;

class CustomLoginController extends Controller
{
    public function showLoginForm()
    {
        return view('auth.custom-login');
    }

    public function loginBak(Request $request)
    {
        /*$request->validate([
            'user_id' => 'required',
            'password' => 'required',
        ]);

        if (Auth::attempt(['user_id' => $request->user_id, 'password' => $request->password], $request->remember)) {
            $request->session()->regenerate();
            return redirect()->intended('/dashboard'); // Redirect to your desired route
        }

        throw ValidationException::withMessages([
            'user_id' => [trans('auth.failed')],
        ]);*/

        $request->validate([
            'user_id' => 'required|exists:users,user_id',
            'password' => 'required',
        ]);

        // Custom authentication logic
        
        if (Auth::attempt(['user_id' => $request->user_id, 'password' => $request->password])) {

            echo "Logged In";
            return redirect()->intended('dashboard'); 
        } else
        {
           echo "Not Logged In"; 
        }

        return back()->withErrors(['login' => 'Invalid User ID or Password.']);
    }

    public function login(Request $request)
    {
        $request->validate([
            'user_id' => 'required',
            'password' => 'required',
        ]);

        $user = User::where('user_id', $request->user_id)->first();

        //if ($user && Hash::check($request->password, $user->password)) {
        //if (Auth::attempt(['user_id' => $request->user_id, 'password' => $request->password])) 
        if (Auth::attempt(['user_id' => $request->user_id, 'password' => $request->password],true)) 
        {
            echo "Logged In";
            Auth::login($user);
            $request->session()->regenerate(); // Ensure session is stored
            return redirect()->route('dashboard')->with('success', 'Login successful');
        } 
        else
        {
            echo "Not Logged In";
        }
        return back()->withErrors(['login' => 'Invalid User ID or Password.']);
        //return back()->with('error', 'Invalid user ID or password');
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        
        return redirect('/');
    }


    public function showMainLogin()
    {
        return view('auth.main_login');
    }

    public function mainLogin(Request $request)
    {
        $credentials = $request->validate([
            'user_id' => ['required'],
            'password' => ['required'],
        ]);
 
        if (Auth::attempt($credentials)) {
            $request->session()->regenerate();
 
            return redirect()->intended('dashboard');
        }
 
        return back()->withErrors([
            'email' => 'The provided credentials do not match our records.',
        ])->onlyInput('user_id');
    }
}