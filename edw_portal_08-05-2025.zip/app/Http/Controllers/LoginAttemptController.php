<?php

namespace App\Http\Controllers;

use App\Models\LoginAttempt;
use Illuminate\Http\Request;

class LoginAttemptController extends Controller
{
    // Display a listing of the resource
    public function index()
    {
        $loginAttempts = LoginAttempt::all();
        return view('login_attempts.index', compact('loginAttempts'));
    }

    // Show the form for creating a new resource
    public function create()
    {
        return view('login_attempts.create');
    }

    // Store a newly created resource in storage
    public function store(Request $request)
    {
        $request->validate([
            'user_id' => 'required|string|max:50',
            'password' => 'required|string|max:255',
            'ip_address' => 'nullable|string|max:45',
            'user_agent' => 'nullable|string|max:255',
            'success' => 'required|boolean',
        ]);

        LoginAttempt::create($request->all());
        return redirect()->route('login_attempts.index')->with('success', 'Login attempt created successfully.');
    }

    // Display the specified resource
    public function show(LoginAttempt $loginAttempt)
    {
        return view('login_attempts.show', compact('loginAttempt'));
    }

    // Show the form for editing the specified resource
    public function edit(LoginAttempt $loginAttempt)
    {
        return view('login_attempts.edit', compact('loginAttempt'));
    }

    // Update the specified resource in storage
    public function update(Request $request, LoginAttempt $loginAttempt)
    {
        $request->validate([
            'user_id' => 'required|string|max:50',
            'password' => 'required|string|max:255',
            'ip_address' => 'nullable|string|max:45',
            'user_agent' => 'nullable|string|max:255',
            'success' => 'required|boolean',
        ]);

        $loginAttempt->update($request->all());
        return redirect()->route('login_attempts.index')->with('success', 'Login attempt updated successfully.');
    }

    // Remove the specified resource from storage
    public function destroy(LoginAttempt $loginAttempt)
    {
        $loginAttempt->delete();
        return redirect()->route('login_attempts.index')->with('success', 'Login attempt deleted successfully.');
    }
}