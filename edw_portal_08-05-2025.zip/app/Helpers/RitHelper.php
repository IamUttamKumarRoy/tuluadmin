<?php

namespace App\Helpers;

// Custom Class import
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Helpers\RitHelper;

// Model import 
use App\Models\User;
use App\Models\BankFiClass;
use App\Models\BankFi;
use App\Models\BankBranch;
use App\Models\DataFrequency;
use App\Models\Department;
use App\Models\RitFeature;
use App\Models\RitSubmission;

class RitHelper
{
    public static function titleCase($string)
    {
        return ucwords(strtolower($string));
    }

    public static function getDepartments()
    {
        return Department::select('id', 'name')->get();
    }

    public static function getActiveFrequencies()
    {
        return DataFrequency::where('status_id', 1)
                         ->orderBy('sorting_order', 'asc')
                         ->select('id', 'short_name','full_name')
                         ->get();
    }

    public static function getActiveDepartments()
    {
        return Department::where('status_id', 1)
                         //->orderBy('sorting_order', 'asc')
                         ->select('id', 'name')
                         ->get();
    }

    public static function getActiveRitFeatures()
    {
        return RitFeature::where('status_id', 1)
                         //->orderBy('sorting_order', 'asc')
                         ->select('rit_id', 'rit_name')
                         ->orderBy('rit_name', 'asc')
                         ->get();
    }

    public static function getActiveBankFi()
    {
        /*return array();*/
        return BankFi::where('status_id', 1)                         
                         ->select('fi_id', 'fi_nm')
                         ->get();
    }

    public static function getBankFi($fi_id)
    {
        /*return array();*/
        return BankFi::where('fi_id', $fi_id)                         
                         ->select('id', 'fi_nm')
                         ->first();
    }

    public static function getBankFiAsArray()
    {
        return BankFi::where('status_id', 1)
                    ->pluck('fi_nm', 'fi_id')
                    ->toArray();                     
    }    

    public static function getBankBranch($fi_branch_id)
    {
        return BankBranch::where('fi_branch_id', $fi_branch_id)                         
                         ->select('id', 'branch_name')
                         ->first();
    }

    public static function getBankBranchAsArray()
    {
        return BankBranch::where('status_id', 1)                         
                         ->pluck('branch_name', 'fi_branch_id') 
                         ->toArray(); 
    }

    public static function findItemId($key, $value) 
    {
        // Example usage:
        $items = [
            ["id" => 1, "name" => "D"],
            ["id" => 2, "name" => "M"],
            ["id" => 3, "name" => "Q"],
            ["id" => 4, "name" => "S"],
            ["id" => 5, "name" => "W"],
            ["id" => 6, "name" => "Y"]
        ];

        foreach ($items as $item) {
            if (isset($item[$key]) && $item[$key] === $value) 
            {
                return $item['id'];
            }
        }
        return -1; // Return -1 if not found
    }
}