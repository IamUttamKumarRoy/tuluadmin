<?php
// Class import
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Session;

// Import controller
use App\Http\Controllers\MigrationController;
use App\Http\Controllers\CsvController;
use App\Http\Controllers\EdwLoginController;
use App\Http\Controllers\CustomLoginController;
use App\Http\Controllers\DepartmentController;
use App\Http\Controllers\DataFrequencyController;
use App\Http\Controllers\BankFiClassController;
use App\Http\Controllers\RitFeatureController;
use App\Http\Controllers\RitSubmissionController;
use App\Http\Controllers\LoginAttemptController;
use App\Http\Controllers\RndLabController;
use App\Http\Controllers\FileController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\CaptchaController;
use App\Http\Controllers\LabController;

//Route::get('upload_status', [ReportController::class, 'uploadStatus'])->name('report.upload_status');

// To generate captcha in the login form
Route::get('/captcha', [CaptchaController::class, 'generate']);

Route::get('captcha_show', [LabController::class, 'captchaShow'])->name('lab.captcha_show');
Route::post('captcha_validate', [LabController::class, 'captchaValidate'])->name('lab.captcha_validate');

Route::get('new_login', [LabController::class, 'loginForm'])->name('lab.login');
Route::post('new_login', [LabController::class, 'login'])->name('lab.login-post');



Route::get('upload-status', [ReportController::class, 'uploadStatus'])->name('report.upload-status');
Route::post('upload-status', [ReportController::class, 'uploadStatus'])->name('report.upload-status');

Route::get('upload-status-rit', [ReportController::class, 'uploadStatusByRit'])->name('report.upload-status-rit');
Route::post('upload-status-rit', [ReportController::class, 'uploadStatusByRit'])->name('report.upload-status-rit');


Route::get('upload', [FileController::class, 'uploadForm']);
Route::post('upload', [FileController::class, 'uploadfile'])->name('test.upload');

Route::get('rit-upload', [RitSubmissionController::class, 'dataUpload'])->name('rit-upload');
Route::post('rit-upload', [RitSubmissionController::class, 'upload'])->name('edw.upload');

Route::get('/get-frequency/{id}', [RitSubmissionController::class, 'getFrequency']);

Route::post('/get-frequencies', [RitSubmissionController::class, 'getFrequencies'])->name('get.frequency');

// Landing or Starting page of the portal
Route::get('/', function () {
    return view('welcome');
});

// Ajax request

// EDW portal routes 
Route::resource('users', UserController::class);

//Route::get('/users/blocked_userlist', [UserController::class, 'blockedUserlist'])->name('users.blocked_userlist');
Route::get('blocked_userlist', [UserController::class, 'blockedUserlist'])->name('users.blocked_userlist');
Route::get('inactive_userlist', [UserController::class, 'inactiveUserlist'])->name('users.inactive_userlist');
Route::get('admin_userlist', [UserController::class, 'adminUserList'])->name('users.admin_userlist');
Route::get('active_userlist', [UserController::class, 'activeUserList'])->name('users.active_userlist');

Route::get('/home', [PageController::class, 'home'])->name('home');
Route::get('/about', [PageController::class, 'about'])->name('about');
Route::get('/contact', [PageController::class, 'contact'])->name('contact');
Route::get('adminlte_dashboard', [PageController::class, 'adminlteDashboard'])->name('adminlte_dashboard');

//Route::resource('roles', RoleController::class);
Route::resource('departments', DepartmentController::class);
Route::resource('data-frequencies', DataFrequencyController::class);
Route::resource('bank-fi-classes', BankFiClassController::class);
Route::resource('rit-features', RitFeatureController::class);
Route::resource('rit-submissions', RitSubmissionController::class);
Route::resource('login-attempts', LoginAttemptController::class);

// Login

Route::get('login', [EdwLoginController::class, 'loginForm'])->name('login');
Route::post('login', [EdwLoginController::class, 'login'])->name('edw.login-submit');
//Route::get('logout', [EdwLoginController::class, 'logout'])->name('edw.logout');
Route::get('logout', [EdwLoginController::class, 'logout'])->name('logout');

Route::get('change-password', [EdwLoginController::class, 'showChangePasswordForm'])->name('change.password.get')->middleware('auth'); 

Route::post('change-password', [EdwLoginController::class, 'submitChangePasswordForm'])->name('change.password.post')->middleware('auth'); 
Route::get('profile', [UserController::class, 'profile'])->name('users.profile');

// End EDW portal routes

// Migrate from Old DB
Route::get('/migrateRitSubmission', [MigrationController::class, 'migrateRitSubmission'])->name('migrate.migrateRitSubmission');
Route::get('/migrateDfiToBankFi', [MigrationController::class, 'migrateDfiToBankFi'])->name('migrate.d_fi');
Route::get('/migrateBankFiClass', [MigrationController::class, 'migrateBankFiClass'])->name('migrate.d_fi_class');
Route::get('/updateBankFiClassIDs', [MigrationController::class, 'updateBankFiClassIDs'])->name('migrate.update_fi_class');
Route::get('/migrateBankBranch', [MigrationController::class, 'migrateBankBranch'])->name('migrate.migrateBankBranch');
Route::get('/migrateRitFeature', [MigrationController::class, 'migrateRitFeature'])->name('migrate.migrateRitFeature');
Route::get('/migrateUser', [MigrationController::class, 'migrateUser'])->name('migrate.migrateUser');
Route::get('/migrateDataFrequency', [MigrationController::class, 'migrateDataFrequency'])->name('migrate.migrateDataFrequency');
Route::get('/updateRitFeature', [MigrationController::class, 'updateRitFeature'])->name('migrate.updateRitFeature');

Route::get('/transferuser', [MigrationController::class, 'transferUserIds'])->name('migrate.user');
Route::get('/transferficlass', [MigrationController::class, 'transferFiClass'])->name('migrate.fi_class');
Route::get('/transferRitFeature', [MigrationController::class, 'transferRitFeature'])->name('migrate.rit_feature');


// R&ND routes 
Route::get('/custom-login', [CustomLoginController::class, 'showLoginForm'])->name('custom.login');
Route::post('/custom-login', [CustomLoginController::class, 'login'])->name('custom.login.submit');

Route::get('/mainlogin', [CustomLoginController::class, 'showMainLogin'])->name('custom.mainlogin');
Route::post('/mainlogin', [CustomLoginController::class, 'mainLogin'])->name('custom.mainloginpost');

Route::get('/custom_logout', [CustomLoginController::class, 'logout'])->name('custom_logout');
//Route::post('/custom_logout', [CustomLoginController::class, 'logout'])->name('custom_logout');

Route::middleware('auth')->group(function () {
    Route::get('/dashboard_custom', function () {
        if (Auth::check()) {
            // User is logged in
            $user = Auth::user();
            echo 'Successful!';
            //return view('dashboard', ['user' => $user]);
        } else {
            echo 'Un Successful!';
            // User is not logged in
            //return redirect('/login'); // Or handle unauthenticated access
        }
    });
});

Route::get('dashboard', [DashboardController::class, 'bankBranchEndDashboard'])->name('dashboard')->middleware('auth'); 


Route::get('/dashboard-2', function () {
    echo 'Welcome to Dashboard!';
    if (Auth::check()) {
        // User is logged in
        $user = Auth::user();

        $logged_user_name      = $user->user_name;
        $logged_fi_id          = $user->fi_id;
        $logged_bank_branch_id = $user->bank_branch_id;
        $logged_role           = $user->role;
        $logged_email          = $user->email;
        $logged_role_id         = $user->role_id;
        $logged_designation    = $user->designation;
        $logged_dept_sec_desk  = $user->dept_sec_desk;
        $logged_cell_no        = $user->cell_no;
        $logged_phone_no       = $user->phone_no;
        //T_ME_D_FRX_ECH_POS.55.550209.20250409
        echo "<br/>";
        echo "User_ID:".$user->user_id."<br/>";
        echo "fi_id:".$user->fi_id."<br/>";
        echo "bank_branch_id:".$user->bank_branch_id."<br/>";
        
        dd($user);
        echo 'Successful!';
        //return view('dashboard', ['user' => $user]);
    } else {
        echo 'Un Successful!';
        // User is not logged in
        //return redirect('/login'); // Or handle unauthenticated access
    }
    dd(Auth::check(), Auth::user(), Session::all());

    //echo "<br/>Why not working";

    //dd(Session::all()); // Debugging session data
    //print_r(Session::all());
})->name('dashboard-2')->middleware('auth');

Route::get('/session-test', function() {
    session(['test' => 'value']);
    return response()->json([
        'session' => session()->all(),
        'auth' => auth()->check(),
        'user' => auth()->user(),
        'cookie' => request()->cookie()
    ]);
});

Route::get('/debug', function () {
    dd(session()->all());
    dd(Auth::user()); // Dumps authenticated user data
});

Route::middleware([CheckPermission::class])->group(function () {
    
    Route::get('/routInfo', [MigrationController::class, 'getUriInfo'])->name('urinfo.get');
 
    Route::get('/routInfo/route', [MigrationController::class, 'getUriInfo'])->name('route.get');
});

//Route::get('/upload-csv', [CsvController::class, 'showUploadForm']);
//Route::post('/upload-csv', [CsvController::class, 'processCsv'])->name('upload-csv');

Route::get('/upload_bank_csv', [CsvController::class, 'uploadBankFiCsv']);
Route::post('/upload_bank_csv', [CsvController::class, 'processBankFiCsv'])->name('upload_bank_fi_csv');


Route::get('/testHelperClass', [RndLabController::class, 'testHelperClass'])->name('rndlab.testHelperClass');
Route::get('/testDbRecord', [RndLabController::class, 'testDbRecord'])->name('rndlab.testDbRecord');

Route::get('/admin/dashboard', [RndLabController::class, 'dashboard'])->name('admin.dashboard');

Route::get('/files', [FileController::class, 'index'])->name('files.index');
Route::get('/files/download/{file}', [FileController::class, 'download'])->name('files.download');

//Route::get('/upload', [FileController::class, 'uploadForm'])->name('files.form');
//Route::post('/files/upload', [FileController::class, 'upload'])->name('files.upload'); 
//Route::get('/departmentFiles', [FileController::class, 'departmentFiles'])->name('files.departmentFiles');


//Route::get('/upload', [FileUploadController::class, 'showForm']);
//Route::post('/upload', [FileUploadController::class, 'uploadFile']);

//Route::get('upload-file', [FileUploadController::class, 'create'])->name('file.upload.form');
//Route::post('upload-file', [FileUploadController::class, 'upload'])->name('file.upload');
// End R&ND


/*
Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';
*/