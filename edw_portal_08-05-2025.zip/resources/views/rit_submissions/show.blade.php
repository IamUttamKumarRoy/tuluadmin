@extends('layouts.app')

@section('content')
    <h1>Submission Details</h1>
    <p><strong>File Name:</strong> {{ $ritSubmission->file_name }}</p>
    <p><strong>Base Date:</strong> {{ $ritSubmission->base_date }}</p>
    <p><strong>Status ID:</strong> {{ $ritSubmission->status_id }}</p>
    <a href="{{ route('rit_submissions.index') }}" class="btn btn-secondary">Back</a>
@endsection