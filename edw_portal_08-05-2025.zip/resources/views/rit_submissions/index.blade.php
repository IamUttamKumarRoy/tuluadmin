@extends('layouts.app')

@section('content')
    <h1>RIT Submissions</h1>
    <a href="{{ route('rit_submissions.create') }}" class="btn btn-primary">Create New Submission</a>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>File Name</th>
                <th>Base Date</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($submissions as $submission)
                <tr>
                    <td>{{ $submission->id }}</td>
                    <td>{{ $submission->file_name }}</td>
                    <td>{{ $submission->base_date }}</td>
                    <td>{{ $submission->status_id }}</td>
                    <td>
                        <a href="{{ route('rit_submissions.show', $submission->id) }}" class="btn btn-info">View</a>
                        <a href="{{ route('rit_submissions.edit', $submission->id) }}" class="btn btn-warning">Edit</a>
                        <form action="{{ route('rit_submissions.destroy', $submission->id) }}" method="POST" style="display:inline;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
@endsection