@extends('layouts.custom_app')

@section('content')


<script>
$(document).ready(function() {
    
    $('#fileNameGivenD').change(function() 
    {
        console.log("Onchange Works");
        var frequencyId = $(this).val();
        if (categoryId) {
            $.ajax({
                url: '/get-frequency/' + frequencyId,
                type: 'GET',
                success: function(data) {
                    $('#fileNameGiven').empty();
                    $('#fileNameGiven').append('<option value="">--Select RIT Name --</option>');
                    $.each(data, function(key, value) {
                        $('#fileNameGiven').append('<option value="' + value.id + '">' + value.rit_name + '</option>');
                    });
                }
            });
        } else {
            $('#fileNameGiven').empty();
            $('#fileNameGiven').append('<option value="">--Select RIT Name --</option>');
        }
    });
});
</script>


<div class="row border-right container-fluid">
<div class="col-md-6">

    @session('success')
    <div class="alert alert-success" role="alert"> 
        {{ $value }}
    </div>
    @if(session('success'))
        <p class="text-success">{{ session('success') }}</p>
    @endif

    @if($errors->any())
        <p class="text-danger">{{ $errors->first() }}</p>
    @endif    
    @endsession
    <h1>Upload File</h1>
    <form action="{{ route('edw.upload') }}" method="POST" enctype="multipart/form-data">
        @csrf
 
            <fieldset>
   
                <div class="form-group">
                    <label>RIT Frequency </label>
                    <label class="text-red"></label>
                    <select name="data_frequency_id" id="ritFrq" style="width:100%;">
                        <option value="0">---Select Frequency---</option>
                        @foreach($rit_frequencies as $frequency)
                        
                        <option value="{{ $frequency->id }}" {{ old('frequency_id') == $frequency->id ? 'selected' : '' }}>
    {{ $frequency->full_name }}
</option>
                        @endforeach 
                    </select> 
                </div>

                <div class="form-group">
                    <label>RIT Name</label>
                    <label class="text-red"></label>
                    <select name="rit_id" id="ritFeature" style="width:100%;">
                        <option value="0">---All---</option>
                    </select> 
                </div>

                <div class="form-group">
                    <label for="reportingDate">Reporting Base Date (mm/dd/yyyy)</label>
                    <label class="text-red"></label>
                    <div class="input-group col-lg-7">
                        <div class="input-group-addon">
                            <i class="fa fa-calendar"></i>
                        </div>
                        <input id="reportingDate" name="reportingDate" class="form-control pull-right" type="text" readonly="">
                    </div>
                </div>


                <div class="form-group" id="cutt" style="display: none;">
                    <label for="cutOffDate" id="cutOff">Cutoff Date (mm/dd/yyyy)</label>
                    <input type="text" class="form-control" id="cutOffDate" name="cutOffDate" readonly="" value="">
                </div>

                <div class="form-group">
                    <label for="preparedBy">Prepared By</label>
                    <label class="text-red"></label>
                    <input type="text" class="form-control" id="preparedBy" name="preparedBy" style="text-transform: uppercase" value="" autocomplete="off">
                </div>

                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <label class="text-red"></label>
                    <input type="text" class="form-control" id="phone" name="phone" value="" autocomplete="off">
                </div>

                <div class="form-group">
                    <div class="row">
                        <div class="col-md-12">
                            <input type="file" id="filename" name="filename" size="20">

                        </div>
                    </div>
                </div> 



                <div class="form-group">
                    <div class="row">
                        <div class="col-md-12">
                            <input type="submit" value="Upload File" class="btn btn-primary">
                        </div>
                    </div>
                </div>
            </fieldset>

            </form>               
</div>
</div>

<script>
        $(document).ready(function() {

            $( "#reportingDate" ).datepicker();    

            $('#ritFrq').change(function() {
                var data_frequency_id = $(this).val();
                var ritFeatureDropdown = $('#ritFeature');

                // Clear existing city options
                ritFeatureDropdown.empty();
                ritFeatureDropdown.append('<option value="">--Select RIT Name --</option>');

                if (data_frequency_id) 
                {
                    $.ajax({
                        url: '{{ route('get.frequency') }}', // Use the route name
                        type: 'POST',
                        data: {
                            data_frequency_id: data_frequency_id,
                            _token: '{{ csrf_token() }}' // Include CSRF token for security
                        },
                        dataType: 'json',
                        success: function(data) 
                        {
                            if (data && Object.keys(data).length > 0) 
                            {
                                $.each(data, function(inc, record) 
                                {
                                    //console.log(record.rit_id);
                                    //console.log(record.rit_name) 
                                    ritFeatureDropdown.append('<option value="' + record.rit_id + '">' + record.rit_name + '</option>');
                                });
                            } else {
                                ritFeatureDropdown.append('<option value="" disabled>No RIT</option>');
                            }
                        },
                        error: function(xhr, status, error) {
                            console.error("AJAX Error:", error);
                            ritFeatureDropdown.append('<option value="" disabled>Error loading cities</option>');
                        }
                    });
                }
            });
        });
    </script>

@endsection