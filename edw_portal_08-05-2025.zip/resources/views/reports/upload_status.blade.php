<!DOCTYPE html>
<html>
<head>
    <title>Upload Status Report</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.14.1/themes/base/jquery-ui.css">
</head>
<body>
    <div class="container mt-5">

<div class="card">
  <div class="card-header">
    Upload Status
  </div>
  <div class="card-body">

    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form method="POST" action="{{ route('report.upload-status') }}" class="row g-3">
       @csrf
      <div class="col-md-6">
        <label for="ritId" class="form-label">RIT Name:</label>
        <select id="ritId" name="rit_id" class="form-select">
          <option selected>Select RIT Name</option>
          <option>...</option>
        </select>
        @error('rit_id')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
      </div>
      <div class="col-md-6">
        <label for="bankId" class="form-label">Bank Name:</label>
        <select id="bankId" name="bank_fi_id" class="form-select">
          <option selected>Choose...</option>
          <option>...</option>
        </select>
        @error('bank_fi_id')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
      </div>


      <div class="col-md-6">
        <label for="reportingBaseDateFrom" class="form-label">Reporting Base Date From:</label>
        <input type="text" name="base_date_from" class="form-control datepickerClass" id="reportingBaseDateFrom">
        @error('base_date_from')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
      </div>
      <div class="col-md-6">
        <label for="reportingBaseDateTo" class="form-label">Reporting Base Date To</label>
        <input type="text" name="base_date_to" class="form-control datepickerClass" id="reportingBaseDateTo">
        @error('base_date_to')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
      </div>

      <div class="col-md-6">
        <label for="uploadDateFrom" class="form-label">Upload Date From:</label>
        <input type="text" name="upload_date_from" class="form-control datepickerClass" id="uploadDateFrom">
        @error('upload_date_from')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
      </div>
      <div class="col-md-6">
        <label for="uploadDateTo" class="form-label">Upload Date To:</label>
        <input type="text" name="upload_date_to" class="form-control datepickerClass" id="uploadDateTo">
        @error('upload_date_to')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
      </div>      
       
      <div class="col-12">
        <button type="submit" class="btn btn-primary">Submit</button>
      </div>
    </form>
   
  </div>
</div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    <script src="https://code.jquery.com/ui/1.14.1/jquery-ui.js"></script>



    <script>
  $( function() {
    $( ".datepickerClass" ).datepicker({
      changeMonth: true,
      changeYear: true
    });
  } );
  </script>
</body>
</html>