<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {        
		Schema::create('roles', function (Blueprint $table) {
            $table->id(); // Equivalent to INT PRIMARY KEY AUTO_INCREMENT
            $table->unsignedInteger('role_id')->nullable(); // role_id INT NOT NULL
            $table->string('name', 255)->unique(); // name VARCHAR(255) NOT NULL
            $table->text('detail')->nullable();
            $table->integer('status_id')->nullable(); // status_id INT NOT NULL
            $table->timestamps(); // Optional: Adds created_at and updated_at columns

            // Indexing for performance
            $table->index('role_id');
            $table->index('name');              

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('roles');
    }
};
