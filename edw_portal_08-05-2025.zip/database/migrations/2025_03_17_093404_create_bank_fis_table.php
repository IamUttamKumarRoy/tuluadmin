<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
		Schema::create('bank_fis', function (Blueprint $table) {
			$table->id();
			$table->unsignedInteger('fi_id'); // FI ID 
			$table->string('fi_nm', 255)->unique(); // FI Name (with unique constraint)
			$table->string('fi_alias', 16)->nullable(); // FI Alias 
			$table->unsignedInteger('geo_area_id')->nullable(); // GEO Area ID 
			$table->unsignedInteger('bank_fi_class_id')->nullable(); // Bank FI Class ID (foreign key)
			$table->timestamps(); // Adds created_at and updated_at columns

			// Indexing for performance
			$table->index('fi_id');
			$table->index('fi_nm');
			$table->index('fi_alias');
			$table->index('bank_fi_class_id');
		});
    }
	

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('bank_fis');
    }
};
