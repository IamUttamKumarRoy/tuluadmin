<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        
        Schema::create('users', function (Blueprint $table) {
            $table->id(); // Auto-incrementing primary key
            $table->string('report_type_id', 100)->nullable(); // report_type_id        
            $table->string('user_id', 100)->unique(); // Unique user ID        
            $table->string('password');
            $table->string('temp_password')->nullable();
            $table->integer('fi_id')->nullable(); // Financial Institution ID
            $table->integer('bank_branch_id')->nullable(); // Financial Institution Branch ID
            $table->string('user_name', 300)->nullable(); // User Name
            $table->integer('role')->nullable(); // User Role
            $table->tinyInteger('role_id')->unsigned()->nullable(); // User Role ID 
            $table->string('status', 20)->nullable(); // User Status
            $table->tinyInteger('status_id')->unsigned()->nullable(); // User Role
            $table->tinyInteger('online')->nullable(); // Online Status
            $table->tinyInteger('block')->nullable(); // Block Status
            $table->string('email', 200)->nullable(); // Email
            $table->string('approve_time', 40)->nullable(); // Approval Time
            $table->string('approved_by', 100)->nullable(); // Approved By
            $table->string('designation', 100)->nullable(); // Designation
            $table->string('dept_sec_desk', 100)->nullable(); // Department/Section Desk
            $table->string('cell_no', 40)->nullable(); // Cell Number
            $table->string('phone_no', 40)->nullable(); // Phone Number
            $table->string('creation_time', 40)->nullable(); // Creation Time
            $table->timestamp('last_login')->useCurrent()->useCurrentOnUpdate(); // Last Login
            $table->integer('failure_attempts')->nullable(); // Failure Attempts            
            $table->string('ip_address', 45)->nullable();
            $table->string('user_agent', 255)->nullable();
            $table->unsignedInteger('created_by')->nullable();
            $table->unsignedInteger('updated_by')->nullable();
            $table->timestamps(); // Created At and Updated At

            // Indexing for performance
            $table->index('user_id');
            $table->index('fi_id');    
            $table->index('bank_branch_id');    
            $table->index('user_name');    
            $table->index('role_id');    
            $table->index('online'); 
            $table->index('block'); 
            $table->index('email'); 

        });

        Schema::create('password_reset_tokens', function (Blueprint $table) {
            $table->string('email')->primary();
            $table->string('token');
            $table->timestamp('created_at')->nullable();
        });

        Schema::create('sessions', function (Blueprint $table) {
            $table->string('id')->primary();
            $table->foreignId('user_id')->nullable()->index();
            $table->string('ip_address', 45)->nullable();
            $table->text('user_agent')->nullable();
            $table->longText('payload');
            $table->integer('last_activity')->index();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('users');
        Schema::dropIfExists('password_reset_tokens');
        Schema::dropIfExists('sessions');
    }
};
