<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('permissions', function (Blueprint $table) {
            $table->id();
            $table->string('name', 100)->unique();
            $table->string('route_name', 100)->nullable();
            $table->string('route_uri', 200)->nullable();
            $table->string('route_action', 100)->nullable();
            $table->string('action_method', 100)->nullable();
            $table->string('http_method', 10)->nullable();
            $table->unsignedInteger('status_id')->nullable();
            $table->string('ip_address', 100)->nullable();
            $table->string('user_agent', 100)->nullable();
            $table->timestamps();

            // Indexing for performance
            $table->index('name');
            $table->index('route_name');    
            $table->index('route_uri');    
            $table->index('route_action');    
            $table->index('action_method');    
            $table->index('http_method');    
            
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('permissions');
    }
};
 