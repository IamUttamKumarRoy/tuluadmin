<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
       

        Schema::create('bank_branches', function (Blueprint $table) {
            $table->id(); // Auto-incrementing primary key
            $table->unsignedInteger('fi_branch_id')->unique(false); // Financial Institution Branch ID
            $table->unsignedInteger('fi_id')->nullable(false); // Financial Institution ID            
            $table->string('branch_name', 100)->nullable(); // Branch Name
            $table->string('division', 50)->nullable(); // Division 
            $table->string('district', 50)->nullable(); // District
            $table->string('thana', 50)->nullable(); // Thana
            $table->unsignedTinyInteger('status_id')->nullable();
            $table->timestamps(); // Created at and Updated at timestamps
            //$table->softDeletes(); // Soft deletes

            // Foreign key constraint
            $table->foreign('fi_id')->references('fi_id')->on('bank_fis')->onDelete('cascade');
            // Indexes
            $table->index('fi_branch_id');
            $table->index('fi_id');
            $table->index('branch_name');
        });

    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('bank_branches');
    }
};
