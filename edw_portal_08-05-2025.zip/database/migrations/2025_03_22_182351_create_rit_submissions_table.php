<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    { 
		Schema::create('rit_submissions', function (Blueprint $table) {
            $table->id();
            $table->unsignedInteger('rit_id')->nullable();
            $table->unsignedInteger('fi_id')->nullable();
            $table->unsignedInteger('bank_branch_id')->nullable();
            $table->string('user_id', 15)->nullable();
            $table->unsignedInteger('data_frequency_id')->nullable();
            $table->string('file_name', 255)->nullable();
            $table->date('base_date')->nullable();
            $table->string('phone_no', 20)->nullable();
            $table->string('prepared_by', 200)->nullable();
            $table->timestamp('upload_time')->nullable();
            $table->unsignedInteger('status_id')->nullable();
            $table->string('ip_address', 100)->nullable();
            $table->text('user_agent')->nullable();
            $table->timestamps();

            // Indexing for performance
            $table->index('rit_id');
            $table->index('fi_id');    
            $table->index('fi_branch_id');    
            $table->index('user_id');    
            $table->index('data_frequency_id');    
            $table->index('file_name'); 
            $table->index('base_date'); 
            $table->index('phone_no'); 
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('rit_submissions');
    }
};
